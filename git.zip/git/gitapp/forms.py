from django import forms
from .models import user_details, repository_details, platform_details, project_file_handle

class user_loginForm(forms.ModelForm):
	class Meta:
		model = user_details
		fields = ['user_mail', 'user_password']

class user_form(forms.ModelForm):
	class Meta:
		model = user_details
		fields = '__all__'

class repository_form(forms.ModelForm):
	class Meta:
		model = repository_details
		fields = '__all__'

class platform_form(forms.ModelForm):
	class Meta:
		model = platform_details
		fields = '__all__'

class project_file_handle_form(forms.ModelForm):
	class Meta:
		model = project_file_handle
		fields = ['project_file']