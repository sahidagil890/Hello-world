from __future__ import unicode_literals
from django.db import models
import os

# def file_upload(instance, filename):
	# get_project_obj = project_detail.objects.get(project_id=instance.project_ref_id)
	# get_repository_obj = repository_details.objects.get(repository_id=get_project_obj.project_id)
	# newpath = 'media/files/'+ str()
	# os.makedirs(newpath)


class user_details(models.Model):
	user_id = models.AutoField(primary_key=True)
	user_name = models.CharField(max_length=50)
	user_profile_id = models.CharField(max_length=50)
	user_mail = models.CharField(max_length=50)
	user_number = models.CharField(max_length=10)
	user_password = models.CharField(max_length=8)
	USER_ROLE = (
		('0', 'superAdmin'),
		('1', 'admin'),
		('2', 'user'),
	)
	user_role = models.CharField(max_length=5, choices=USER_ROLE)
	USER_STATUS = (
		('0', 'inactive'),
		('1', 'active'),
	)
	user_status = models.CharField(max_length=5, choices=USER_STATUS)
	def __unicode__(self):
		return self.user_name
	class Meta:
		db_table = "vcs_user_table"

class repository_details(models.Model):
	repository_id = models.AutoField(primary_key=True)
	repository_name = models.CharField(max_length=40)
	repository_create_date = models.DateTimeField(auto_now_add=True)
	REPOSITORY_STATUS = (
		('0', 'inactive'),
		('1', 'active'),
	)
	repository_status = models.CharField(max_length=2, choices=REPOSITORY_STATUS)
	def __unicode__(self):
		return self.repository_name
	class Meta:
		db_table = "vcs_repository_table"	

class platform_details(models.Model):
	platform_id = models.AutoField(primary_key=True)
	platform_name = models.CharField(max_length=40)
	platform_create_date = models.DateTimeField(auto_now_add=True)
	PLATFORM_STATUS = (
		('0', 'inactive'),
		('1', 'active'),
	)
	platform_status = models.CharField(max_length=2, choices=PLATFORM_STATUS)
	def __unicode__(self):
		return self.platform_name
	class Meta:
		db_table = "vcs_platform_table"	

class project_details(models.Model):
	project_id = models.AutoField(primary_key=True)
	project_name = models.CharField(max_length=30)
	project_user_admin = models.ForeignKey(user_details)
	project_user = models.TextField(blank=True, null=True)
	project_platform = models.ForeignKey(platform_details)
	project_repository = models.ForeignKey(repository_details)
	project_create_date = models.DateTimeField(auto_now_add=True)
	PROJECT_STATUS = (
		('0', 'inactive'),
		('1', 'active'),
	)
	project_status = models.CharField(max_length=5, choices=PROJECT_STATUS)
	def __unicode__(self):
		return str(self.project_id)
	class Meta:
		db_table = "vcs_project_table"

class project_file_handle(models.Model):
	file_id = models.AutoField(primary_key=True)
	project_ref_id = models.ForeignKey(project_details, blank=True, null=True)
	project_file = models.FileField(upload_to='files/', max_length=254)
	FILE_STATUS = (
		('0', 'inactive'),
		('1', 'active'),
	)
	file_status = models.CharField(max_length=5, choices=FILE_STATUS)
	def __unicode__(self):
		return str(self.file_id)
	class Meta:
		db_table = "vcs_files_table"