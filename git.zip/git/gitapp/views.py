from __future__ import unicode_literals
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import user_details, repository_details, platform_details, project_details, project_file_handle
from .forms import user_loginForm, repository_form, platform_form, user_form, project_file_handle_form
from django.db.models import Q
import json

def index(request):
	if request.method == 'POST':
		form = user_loginForm(request.POST)
		if form.is_valid():
			user_mail_obj = form.cleaned_data['user_mail']
			user_password_obj = form.cleaned_data['user_password']
			try:
				user_obj = user_details.objects.get(Q(user_mail__exact=user_mail_obj) & Q(user_password__exact=user_password_obj))
				request.session['user_name'] = user_obj.user_name
				request.session['user_id'] = user_obj.user_id
				request.session['user_role'] = user_obj.user_role
				# check = 0
				# for i in user_obj:
				# 	if i.user_mail != user_mail_obj:
				# 		check += 1
				# 	if i.user_password != user_password_obj:
				# 		check += 2
				# if check == 0:
				# 	get_user_obj = user_details.objects.get(Q(user_mail=user_mail_obj))
				return HttpResponse('0')
			except:
				return HttpResponse('4')
				pass
		else:
			return HttpResponse('5')
	else:
		return render(request, 'index.html')

def sign_out(request):
	if 'user_name' in request.session:
		del request.session['user_name']
	if 'user_role' in request.session:
		del request.session['user_role']
	return redirect('/login')

def dashboardView(request):
	context = {
		'repository_list': repository_details.objects.filter(repository_status=1),
	}
	return render(request, 'dashboard.html', context)

def repository(request):
	context = {
		'repository': repository_details.objects.filter(repository_status=1),
	}
	return render(request, 'repository.html', context)

def add_repository(request, action):
	import os
	if request.method == 'POST':
		if action == '1':
			repository_add_form = repository_form(request.POST)
			if repository_add_form.is_valid():
				try:
					repository_add_form.save()
					last_repository_obj = repository_details.objects.all().last()
					get_repository_obj = repository_details.objects.get(repository_id=last_repository_obj.repository_id)
					create_dir = str(get_repository_obj.repository_name) + str(get_repository_obj.repository_id)
					newpath = './media/files/'+ str(create_dir)
					if not os.path.exists(newpath):
					    os.makedirs(newpath)
					return HttpResponse('1')
				except:
					return HttpResponse('2')
					pass
			else:
				return HttpResponse('3')
		if action == '2':
			repository_edit_form = repository_form(request.POST, instance=repository_details.objects.get(repository_id=request.POST['repository_id']))
			if repository_edit_form.is_valid():
				try:
					repository_edit_form.save()
					return HttpResponse('1')
				except:
					return HttpResponse('2')
					pass
			else:
				return HttpResponse('3')
		if action == '3':
			repository_delete_obj = repository_details.objects.filter(repository_id=request.POST['id']).update(repository_status=0)
			return HttpResponse('1')
	else:
		return HttpResponse(action)

def platformView(request):
	context = {
		'platform': platform_details.objects.filter(platform_status=1)
	}
	return render(request, 'platform.html', context)

def platform(request, action):
	# return HttpResponse(action)
	if request.method == 'POST':
		if action == '1':
			platform_add_form = platform_form(request.POST)
			if platform_add_form.is_valid():
				try:
					platform_add_form.save()
					return HttpResponse('1')
				except:
					return HttpResponse('2')
					pass
			else:
				return HttpResponse('3')
		if action == '2':
			platform_edit_form = platform_form(request.POST, instance=platform_details.objects.get(platform_id=request.POST['platform_id']))
			if platform_edit_form.is_valid():
				try:
					platform_edit_form.save()
					return HttpResponse('1')
				except:
					return HttpResponse('2')
					pass
			else:
				return HttpResponse('3')
		if action == '3':
			platform_delete_obj = platform_details.objects.filter(platform_id=request.POST['id']).update(platform_status=0)
			return HttpResponse('1')
	else:
		return HttpResponse(action)

def userView(request):
	context = {
		'users': user_details.objects.filter(~Q(user_role=1) & Q(user_status=1)),
	}
	return render(request, 'users.html', context)

def user(request, action):
	if request.method == 'POST':
		if action == '1':
			user_add_form = user_form(request.POST)
			if user_add_form.is_valid():
				try:
					chq_user_mail = user_details.objects.filter(user_mail=user_add_form.cleaned_data['user_mail']).count()
					if chq_user_mail == 0:
						user_add_form.save()
						return HttpResponse('1')
					else:
						return HttpResponse('4')
				except:
					return HttpResponse('2')
					pass
			else:
				return HttpResponse('3')
		if action == '2':
			user_edit_form = user_form(request.POST, instance=user_details.objects.get(user_id=request.POST['user_id']))
			if user_edit_form.is_valid():
				try:
					user_edit_form.save()
					return HttpResponse('1')
				except:
					return HttpResponse('2')
					pass
			else:
				return HttpResponse('3')
		if action == '3':
			user_delete_obj = user_details.objects.filter(user_id=request.POST['id']).update(user_status=0)
			return HttpResponse('1')
	else:
		return HttpResponse(action)

def repository_page(request, id, name):
	import os
	from django.core.files import File
	project_obj = project_details.objects.filter(Q(project_repository=id) & Q(project_status=1))
	files = []
	for i in project_file_handle.objects.filter(project_ref_id__in=project_obj):
		path = str(i.project_file)
		for r, d, f in os.walk(path):
			for file in f:
				files.append(os.path.join(r, file))
	a = []
	for f in files:
		split_file = f.split('/')
		a.append('/'.join(split_file[2:]))
	context = {
		'id': id,
		'name': name,
		'files': a,
		'project_obj': project_obj,
		'file_obj': project_file_handle.objects.filter(project_ref_id__in=project_obj),
	}
	return render(request, 'userRepository.html', context)

def upload_project(request, id, name):
	context = {
		'platform_obj': platform_details.objects.filter(platform_status=1),
		'user_obj': user_details.objects.filter(Q(user_status=1) & ~Q(user_role=1)),
		'id': id,
		'name': name,
	}
	return render(request, 'uploadProject.html', context)

def create_project(request):
	from zipfile import ZipFile
	import os
	user_arr = []
	if request.method == 'POST':
		ajax_project_name = request.POST['project_name']
		ajax_project_user = request.POST.getlist('project_user[]')
		ajax_project_platform = request.POST['project_platform']
		ajax_project_rep_id = request.POST['project_repository']
		check = []
		if len(ajax_project_user) == 0:
			create_project_details = project_details(project_name=ajax_project_name, project_user_admin_id=request.session['user_id'], project_user=None, project_platform_id=ajax_project_platform, project_repository_id=ajax_project_rep_id, project_status=1)
		else :
			filter_user_details = user_details.objects.filter(user_id__in=ajax_project_user)
			for i in filter_user_details:
				data = {
					'id': i.user_id,
					'name': i.user_name,
				}
				user_arr.append(data)
			create_project_details = project_details(project_name=ajax_project_name, project_user_admin_id=request.session['user_id'], project_user=json.dumps(user_arr), project_platform_id=ajax_project_platform, project_repository_id=ajax_project_rep_id, project_status=1)
		create_project_details.save()
		
		filter_last_file_obj = project_file_handle(project_ref_id_id=create_project_details.project_id, file_status=1)
		filter_last_file_obj.save()
		last_file_obj = project_file_handle.objects.all().last()
		file_handle_form = project_file_handle_form(request.POST, request.FILES, instance=project_file_handle.objects.get(file_id=last_file_obj.file_id))
		if file_handle_form.is_valid():
			file_handle_form.save()
		get_last_file_obj = project_file_handle.objects.get(file_id=last_file_obj.file_id)
		get_project_obj = project_details.objects.get(project_id=create_project_details.project_id)
		get_repository_obj = repository_details.objects.get(repository_id=get_project_obj.project_repository_id)
		file_name = 'media/'+ str(get_last_file_obj.project_file)
		file_path = 'media/files/'+ str(get_repository_obj.repository_name) + str(get_repository_obj.repository_id)

		dot_split = str(get_last_file_obj.project_file).split('.')
		del dot_split[-1]
		slash_split = ','.join(dot_split).split('/')
		with ZipFile(file_name, 'r') as zip_ref:
			for i in range(1, 10000):
				c = str(i)
				set_path = str(file_path) + '/' + ','.join(slash_split[1:]) + '-' + c
				if not os.path.exists(set_path):
				    os.makedirs(set_path)
				    zip_ref.extractall(set_path)
				    break
		os.remove(file_name)
		update_path = set_path + '/' + ','.join(slash_split[1:])
		project_file_handle.objects.filter(file_id=get_last_file_obj.file_id).update(project_file=update_path)
		return HttpResponse('1')
	else:
		return HttpResponse('fail')