from django.conf.urls import url
from django.contrib import admin
from gitapp import views
from django.conf import settings
from django.conf.urls.static import static 

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^login/', views.index),
    url(r'^sign_out/', views.sign_out),
    url(r'^dashboard/', views.dashboardView),

    # Repository 
    url(r'^repository/', views.repository),
    url(r'^add_repository/(?P<action>[0-9]+)/$', views.add_repository),
    # Platform
    url(r'^platform/$', views.platformView),
    url(r'^platform/(?P<action>[0-9]+)/$', views.platform),
    # users
    url(r'^users/$', views.userView),
    url(r'^user/(?P<action>[0-9]+)/$', views.user),
    # view page
    url(r'^user_repository/(?P<id>[0-9]+)/(?P<name>[\w.@+-]+)/$', views.repository_page),
    url(r'^upload_project/(?P<id>[0-9]+)/(?P<name>[\w.@+-]+)/$', views.upload_project),
    url(r'^create_project/$', views.create_project),
    # url(r'^file_save_func/$', views.file_save_func),

]

if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)
