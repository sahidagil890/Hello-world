from django.conf.urls import url
from django.contrib import admin
from hotel import views
from django.conf import settings
from django.conf.urls.static import static 

urlpatterns = [
    url(r'^admin/', admin.site.urls),

    # /---- Login And SignOut ----/

    url(r'^index/', views.index),
    url(r'^signOut/', views.signOut),

    # /---- Dashboard For Admin ----/

    url(r'^dashboard/$', views.dashboard_inventory),
    # url(r'^dashboard/$', views.dashboard),
    url(r'^pos_inv_category/(?P<id>[0-9]+)/$', views.pos_inv_category_func),
    url(r'^pos_inv_product/(?P<id>[0-9]+)/$', views.pos_inv_product_func),
    url(r'^pos_inv_supplier/(?P<id>[0-9]+)/$', views.pos_inv_supplier_func),
    
    url(r'^pos_inv_stock_order/$', views.pos_inv_stock_order_func),
    url(r'^pos_inv_order/$', views.pos_inv_order_func),
    url(r'^order_arr_func/$', views.order_arr_func),
    url(r'^order_update_unit_func/$', views.order_update_unit_func),
    url(r'^create_order/(?P<id>[0-9]+)/(?P<val>[0-9]+)/$', views.create_order),
    url(r'^pos_inv_edit_order/(?P<id>[0-9]+)/$', views.pos_inv_edit_order_func),
    url(r'^pos_inv_del_order/$', views.pos_inv_del_order_func),
    url(r'^pos_inv_send_order/(?P<id>[0-9]+)/$', views.pos_inv_send_order_func),


    url(r'^pos_inv_purchase/$', views.pos_inv_purchase_func),
    url(r'^pos_inv_add_purchase/$', views.add_purchase_entry_func),
    url(r'^pos_inv_purchase_return/(?P<id>[0-9]+)/$', views.pos_inv_purchase_return_func),
    url(r'^pos_inv_purchase_return_save/(?P<id>[0-9]+)/$', views.pos_inv_purchase_return_save),
    url(r'^order_show/(?P<id>[0-9]+)/$', views.order_show_func),
    url(r'^order_show_update/$', views.order_show_update_func),
    url(r'^pos_inv_enter_purchase_bill/$', views.pos_inv_enter_purchase_bill_func),
    url(r'^purchase_edit/(?P<id>[0-9]+)/$', views.purchase_edit_func),
    url(r'^edit_order_update/(?P<id>[0-9]+)/$', views.edit_order_update_func),
    url(r'^order_show_edit_update/(?P<id>[0-9]+)/$', views.order_show_edit_update_func),
    url(r'^pos_inv_bill_payment/$', views.pos_inv_bill_payment_func),

    url(r'^kitchen_order_show/$', views.kitchen_order_show),
    url(r'^select_kitchen_order/(?P<id>[0-9]+)/$', views.select_kitchen_order),
    url(r'^select_category_product/$', views.select_category_product),
    url(r'^select_kitchen_product/$', views.select_kitchen_product),
    url(r'^kitchen_set_qty/$', views.kitchen_set_qty),
    url(r'^kitchen_delete_product/$', views.kitchen_delete_product),
    url(r'^create_kitchen_products/(?P<role>[0-9]+)/(?P<save_order>[0-9]+)/$', views.create_kitchen_products),
    url(r'^edit_kitchen_delivery/(?P<id>[0-9]+)/(?P<ref>[0-9]+)/$', views.edit_kitchen_delivery),
    url(r'^edit_kitchen_product/(?P<id>[0-9]+)/$', views.edit_kitchen_product),
    url(r'^chef_sended_orders/(?P<id>[0-9]+)/$', views.chef_sended_orders),
    
    # url(r'^report/(?P<id>[0-9]+)/$', views.report_func),
    url(r'^clear_report_order/$', views.clear_report_order),

    url(r'^clear_purchase_session/$', views.clear_session_func),
    url(r'^confirm_purchase/(?P<order>[0-9]+)/$', views.confirm_purchase),
    url(r'^pos_inv_units/(?P<id>[0-9]+)/$', views.pos_inv_units_func),
    url(r'^admins/(?P<action>[0-9]+)/$', views.pos_admins),
    url(r'^change_password/$', views.change_password),
    url(r'^pos_inv_stock_show/$', views.pos_inv_stock_show),
    url(r'^pos_inv_department/(?P<id>[0-9]+)/$', views.pos_inv_department),
    url(r'^inv_report_page/$', views.common_reports),
    url(r'^order_report/(?P<id>[0-9]+)/$', views.order_report),
    url(r'^purchase_report/(?P<id>[0-9]+)/$', views.purchase_report),
    url(r'^kitchen_report/(?P<id>[0-9]+)/$', views.kitchen_report),
    url(r'^supplier_accounts/(?P<id>[0-9]+)/$', views.supplier_accounts_func),
    url(r'^supplier_add_accounts/(?P<id>[0-9]+)/$', views.supplier_add_accounts),
    url(r'^settings/$', views.inv_settings),
    url(r'^add_mail_func/$', views.add_mail_func),
    url(r'^editSettings/$', views.edit_settings),
    url(r'^return_purchase_reports/(?P<id>[0-9]+)/$', views.return_purchase_reports),
    url(r'^transaction_report/(?P<id>[0-9]+)/$', views.transaction_report),

    # /---- employees url ----/


    # /---- For Changing password ----/
    # url(r'^time_out_func/$', views.time_out_func),

    # url(r'^mailFunc/$', views.mailFunc),
    # url(r'^add_mail_func/$', views.add_mail_func),
    
    # url(r'^re_create_password/(?P<id>[0-9]+)/$', views.re_create_password),
    # url(r'^resetPassword/$', views.resetPassword),
]

if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)
