function validate_form(id){
	var chq=0;
	var form = $("#"+id);
	if(form.length>0){
		var txt_inp=form.find("input[type='text'].custom-validate");
		var num_inp=form.find("input[type='number'].custom-validate");
		var file_inp=form.find("input[type='file'].custom-validate");
		var radio_inp=form.find("input[type='radio'].custom-validate");
		var check_inp=form.find("input[type='checkbox'].custom-validate");
		var spcl_check_inp=form.find("input[type='checkbox'].custom-validate.spcl-check");
		var txtarea_inp=form.find("textarea.custom-validate");
		var sel_inp=form.find("select.custom-validate");
		if(txt_inp.length>0){
			$.each(txt_inp, function(i) {
				if($.trim(txt_inp[i].value)==""){
					form.find("input[name='"+txt_inp[i].name+"'].custom-validate").parent().addClass('err');
					chq++;
				}else{
					form.find("input[name='"+txt_inp[i].name+"'].custom-validate").parent().removeClass('err');
					if(txt_inp[i].className.match("mobile_no")!=null){
						var mob = new RegExp("^[6-9]{1}[0-9]{9}$");
				        if(mob.test(txt_inp[i].value)){
				        	form.find("input[name='"+txt_inp[i].name+"'].custom-validate").parent().find(".mobile_no_err").remove();
							form.find("input[name='"+txt_inp[i].name+"'].custom-validate").parent().removeClass('err');
				        }else{
				        	form.find("input[name='"+txt_inp[i].name+"'].custom-validate").parent().append("<span class='mobile_no_err small'>Enter Valid Mobile Number</span>");
							form.find("input[name='"+txt_inp[i].name+"'].custom-validate").parent().addClass('err');
							chq++;
				        }
					}else if(txt_inp[i].className.match("mail-validate")!=null){
						var mail_test = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				        if(mail_test.test(String(txt_inp[i].value).toLowerCase())){
				        	form.find("input[name='"+txt_inp[i].name+"'].custom-validate.mail-validate").parent().find(".mobile_no_err").remove();
							form.find("input[name='"+txt_inp[i].name+"'].custom-validate.mail-validate").parent().removeClass('err');
				        }else{
				        	form.find("input[name='"+txt_inp[i].name+"'].custom-validate.mail-validate").parent().append("<span class='mobile_no_err small'>Enter Valid Mail ID</span>");
							form.find("input[name='"+txt_inp[i].name+"'].custom-validate.mail-validate").parent().addClass('err');
							chq++;
				        }
					}
				}
			});
		}

		if(num_inp.length>0){
			$.each(num_inp, function(i) {
				if($.trim(num_inp[i].value)==""){
					form.find("input[name='"+num_inp[i].name+"'].custom-validate").parent().addClass('err');
					chq++;
				}else{
					form.find("input[name='"+num_inp[i].name+"'].custom-validate").parent().removeClass('err');
					if(num_inp[i].className.match("mobile_no")!=null){
						var mob = new RegExp("^[6-9]{1}[0-9]{9}$");
				        if(mob.test(num_inp[i].value)){
				        	form.find("input[name='"+num_inp[i].name+"'].custom-validate").parent().find(".mobile_no_err").remove();
							form.find("input[name='"+num_inp[i].name+"'].custom-validate").parent().removeClass('err');
				        }else{
				        	form.find("input[name='"+num_inp[i].name+"'].custom-validate").parent().append("<span class='mobile_no_err small'>Enter Valid Mobile Number</span>");
							form.find("input[name='"+num_inp[i].name+"'].custom-validate").parent().addClass('err');
							chq++;
				        }
					}
				}
			});
		}

		if(file_inp.length>0){
			$.each(file_inp, function(i) {
				if($.trim(file_inp[i].value)==""){
					var file = form.find("input[name='"+file_inp[i].name+"'].custom-validate");
					file.parent().find('label').addClass("err");
					file.parent().find("span.dp_err").remove();
					file.parent().append("<span class='dp_err'>Set an Image</span>");
					chq++;
				}else{
					var file = form.find("input[name='"+file_inp[i].name+"'].custom-validate");
					file.parent().find('label').removeClass("err");
					file.parent().find("span.dp_err").remove();
				}
			});
		}

		if(sel_inp.length>0){
			$.each(sel_inp, function(i) {
				if($.trim(sel_inp[i].value)==""){
					form.find("select[name='"+sel_inp[i].name+"'].custom-validate").parent().addClass('err');
					chq++;
				}else{
					form.find("select[name='"+sel_inp[i].name+"'].custom-validate").parent().removeClass('err');
				}
			});
		}

		if(txtarea_inp.length>0){
			$.each(txtarea_inp, function(i) {
				if($.trim(txtarea_inp[i].value)==""){
					form.find("textarea[name='"+txtarea_inp[i].name+"'].custom-validate").parent().addClass('err');
					chq++;
				}else{
					form.find("textarea[name='"+txtarea_inp[i].name+"'].custom-validate").parent().removeClass('err');
				}
			});
		}

		if(radio_inp.length>0){
			$.each(radio_inp, function(i) {
				var j = i;
				if(i<radio_inp.length-1){
					j++;
					if(radio_inp[i].name==radio_inp[j].name){
						if((radio_inp[i].checked==true) || (radio_inp[j].checked==true)){
							form.find("input[name='"+radio_inp[i].name+"'].custom-validate").parent().parent().parent().removeClass('err');
						}else{
							form.find("input[name='"+radio_inp[i].name+"'].custom-validate").parent().parent().parent().addClass('err');
							chq++;
						}
					}
				}
			});
		}

		if(check_inp.length>0){
			$.each(check_inp, function(i) {
				var k = i;
				if(i<check_inp.length-1){
					k++;
					if(check_inp[i].name==check_inp[k].name){
						if((check_inp[i].checked==true) || (check_inp[k].checked==true)){
							form.find("input[name='"+check_inp[i].name+"'].custom-validate").parent().parent().parent().removeClass('err');
						}else{
							form.find("input[name='"+check_inp[i].name+"'].custom-validate").parent().parent().parent().addClass('err');
							chq++;
						}
					}
				}
			});
		}

		if(spcl_check_inp.length>0){
			var ch=0;
			$.each(spcl_check_inp, function(i) {
				if(spcl_check_inp[i].checked==true){
					ch++;
				}
			});
			if(ch>0){
				form.find("input.custom-validate.spcl-check").parent().parent().parent().removeClass('err');
			}else{
				form.find("input.custom-validate.spcl-check").parent().parent().parent().addClass('err');
				chq++;
			}
		}

	}

	if(chq==0){
		return true;
	}else{
		form.find(".form_submit .form_err").remove();
		form.find(".form_submit").append("<span class='form_err animated headShake small'><i class='fa fa-info-circle mr-2'></i>Fill The Required Fields</span>");
		setTimeout(function(){ form.find(".form_submit .form_err").remove(); },2500);
		return false;
	}

}

$("input[type='text'], input[type='number'], textarea").keyup(function(){
	var inp = $(this);
	if($.trim(inp.val()).length>0){
		$(this).parent().removeClass('err');
	}else{
		$(this).parent().addClass('err');
	}
});

$("input[type='text'].dateField").change(function(){
	var inp = $(this);
	if($.trim(inp.val()).length>0){
		$(this).parent().removeClass('err');
	}else{
		$(this).parent().addClass('err');
	}
});

$("input[type='file']").on('change',function(){
	var inp = $(this);
	if($.trim(inp.val()).length>0){
		inp.parent().find('label').removeClass("err");
		$("span.dp_err").remove();
	}else{
		inp.parent().find('label').addClass("err");
		inp.parent().append("<span class='dp_err'>Set an Image</span>");
	}
});

$("input[type='text'], input[type='number'], textarea").on('change',function(){
	var inp = $(this);
	inp.val($.trim(inp.val()));
});

$("select").on('change',function(){
	var inp = $(this);
	if($.trim(inp.val()).length>0){
		$(this).parent().removeClass('err');
	}else{
		$(this).parent().addClass('err');
	}
});

$("input[type='checkbox'], input[type='radio']").click(function(){
	var inp = $(this);
	if(inp.prop('checked')==true){
		$(this).parent().parent().parent().removeClass('err');
	}else{
		$(this).parent().parent().parent().addClass('err');
	}
});

$("textarea").keyup(function(){
	if($.trim($(this).val())==""){
		$(this).addClass('err');
	}else{
		$(this).removeClass('err');
	}
});

$("input[type='number']").on('mousewheel', function (e) {
	e.preventDefault();
});

$( "input[type='text'].number-only" ).keydown(function(e){
	var numbersChars = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "Backspace", "Control", "Tab", "ArrowRight", "ArrowLeft"];
	if(!numbersChars.includes(e.key)){
		e.preventDefault();
	}
});

$( "input[type='text'].decimal-number-only" ).keydown(function(d){
	var numbersCharss = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "Backspace", "Control", "Tab", "ArrowRight", "ArrowLeft", "."];
	if(!numbersCharss.includes(d.key)){
		d.preventDefault();
	}
});

$( "input[type='number']" ).keydown(function(e) {
	var invalidChars = ["-", "+", "e"];
	if (invalidChars.includes(e.key)) {
	  e.preventDefault();
	}

	if (e.which === 38 || e.which === 40) {
		e.preventDefault();
    }
});

function readURL(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
			$("#"+input.id).parent().find('.image-preview img').attr('src', e.target.result);
			$("#"+input.id).parent().find('.image-preview img').attr('title', "Change Image");
		}
		reader.readAsDataURL(input.files[0]);
	}
}

$('.custom-validate.age-check').on('change', function(){
	if (this.value == ''){
		$(this).parent().addClass('err');
	} else {
		$(this).parent().removeClass('err');
		if((this.value < 18)||(this.value > 99)){
			$(this).parent().addClass('err');
			$(this).parent().append("<span class='age_err err_clr position-absolute small'>Enter Valid Age</span>");
		} else {
			$(this).parent().find('.age_err').remove();
			$(this).parent().removeClass('err');
		}
	}
})

function currentTime(){
	var date = new Date();
	var hour = date.getHours();
	var min = date.getMinutes();
	var sec = date.getSeconds();
	var month = date.getMonth();
	var days = new Array(7);
	days[0] = "Sunday";
	days[1] = "Monday";
	days[2] = "Tuesday";
	days[3] = "Wednesday";
	days[4] = "Thursday";
	days[5] = "Friday";
	days[6] = "Saturday";
	day = days[date.getDay()];
	setHours = (hour == 0) ? 12 : ((hour > 12) ? (hour - 12): hour);
	setSession = (hour >= 12) ? "PM" : "AM";
	document.getElementById("current_day").innerText = String(day);
	document.getElementById("current_month").innerText = String(moment().format('MMM DD, YYYY'))+ " ";
	$("#current_time").html("<div style='display:inline-block;width:20px;'>"+String(setHours).padStart(2,'0')+"</div>"+ " : "+"<div style='display:inline-block;width:20px;'>"+ String(min).padStart(2,'0') +"</div>"+" : " + "<div style='display:inline-block;width:25px;'>" + String(sec).padStart(2,'0') +"</div>"+ " " + String(setSession).padStart(2,'0'));
	var t = setTimeout(function(){ currentTime() }, 1000);
}

$(".search_filter_box, #search_filter_box").click(function(){
	$(this).addClass('filter-active').find("input").focus();
});

$("body").click(function(e){
	var container = $("#search_filter_box, .search_filter_box");
	if(container.length>0){
		if (!container.is(e.target) && container.has(e.target).length===0){
		  if(container.find("input[type='text']").val().length==0){
		  	// alert(container.find("input[type='text']").val().length);
		  	container.removeClass('filter-active');
		  }
		}
	}
});

function raiseAlert(msg){
	$(".order-note").find('.custom-note span').html(msg);
	$(".order-note").addClass('animated slideInUp fast').fadeIn();
	setTimeout(function(){
		$(".order-note").removeClass('animated slideInUp fast').fadeOut();
	}, 2500);
}