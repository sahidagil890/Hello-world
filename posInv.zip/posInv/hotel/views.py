from __future__ import unicode_literals
import json
import os
import io
from io import StringIO
import csv
from io import BytesIO
from datetime import datetime
from django.template import loader
from django.contrib import messages
from reportlab.pdfgen import canvas
from django.db.models import Q, Count, Sum
from django.utils import formats, timezone
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
from django.contrib.sessions.models import Session
from django.template.loader import render_to_string
from django.views.decorators.http import require_POST
from django.shortcuts import render, redirect, render_to_response
from django.http import HttpResponse, JsonResponse, FileResponse, HttpResponseRedirect
from django.core.paginator import Paginator
from django.core.mail import send_mail, EmailMultiAlternatives, EmailMessage
import random
from .models import pos_employee, pos_inv_category, pos_inv_units, pos_inv_product, pos_inv_supplier, pos_inv_stock_order, pos_inv_product_stock, pos_inv_purchase_details, pos_inv_bill_payment, pos_inv_kitchen_delivery, pos_inv_kitchen_department, pos_inv_supplier_account_details, pos_inv_settings
from .forms import loginForm, pos_employee_form, pos_edit_employee_form, inv_category_form, inv_product_form, inv_supplier_form, inv_purchase_details_form, pos_inv_units_form, pos_inv_kitchen_department_form, inv_supplier_acc_form, pos_inv_settings_form

        # /---- Login Func ----/

def includeFunc(request):
    date = timezone.now()
    return render(request, 'include.html', {'date':date})

def index(request):
    if request.method == 'POST':
        lform = loginForm(request.POST)
        if lform.is_valid():
            user_name = lform.cleaned_data['emp_name']
            user_password = lform.cleaned_data['emp_password']
            user_type = lform.cleaned_data['emp_role']
            try:
                if user_type == '1':
                    users = pos_employee.objects.get(Q(emp_name=user_name) & Q(emp_name__contains=user_name) & Q(emp_password__contains=user_password) & Q(emp_password=user_password) & Q(emp_role=1))
                else:
                    users = pos_employee.objects.get(Q(emp_name=user_name) & Q(emp_name__contains=user_name) & Q(emp_password__contains=user_password) & Q(emp_password=user_password) & ~Q(emp_role=1))
                request.session['user_name'] = users.emp_name
                request.session['user_role'] = users.emp_role
                request.session['user_id'] = users.id
                request.session['user_pic'] = str(users.emp_img)
                if request.session['user_role'] == '1':
                    data = {
                        'status': 1,
                        'redirect': 'dashboard',
                    }
                    dump = json.dumps(data)
                else:
                    data = {
                        'status': 1,
                        'redirect': 'kitchen_order_show',
                    }
                    dump = json.dumps(data)
                return HttpResponse(dump, content_type='application/json')
            except:
                return HttpResponse(users)
                data = {
                    'status': 2,
                    'redirect': 'Invalid Username or Password',
                }
                dump = json.dumps(data)
                return HttpResponse(dump, content_type='application/json')
        else:
            data = {
                'status': 3,
                'redirect': 'Invalid Username or Password',
            }
            dump = json.dumps(data)
            return HttpResponse(dump, content_type='application/json')
    else:
        if 'user_role' in request.session:
            del request.session['user_role']
        if 'user_id' in request.session:
            del request.session['user_id']
        lform = loginForm()
        return render(request, 'index.html')

        # /---- SignOut Func ----/

def signOut(request):
    if 'user_id' in request.session:
        if request.session['user_role'] == '1' :
            del request.session['user_id']
            request.session.flush()
            return HttpResponse('2')
        else:
            check_sign_out_for_in_order = pos_billing.objects.filter(Q(cap_id_id=request.session['user_id'])&Q(status=1))
            if check_sign_out_for_in_order:
                return HttpResponse('1')
            else:
                attendance_report = pos_attendance.objects.filter(attendance_cap_id_id=request.session['user_id']).last()
                attendance_rep = pos_attendance.objects.filter(id=attendance_report.id).update(log_out_time=timezone.now())
                del request.session['user_id']
                request.session.flush()
                return HttpResponse('2')

def pos_admins(request, action):
    if 'user_id' in request.session and request.session['user_role'] == '1':
        if action == "1":
            if request.method == 'POST':
                emp_form = pos_employee_form(request.POST, request.FILES)
                if emp_form.is_valid():
                    try:
                        a = pos_employee.objects.filter(Q(Q(emp_name__contains=emp_form.cleaned_data['emp_name']) | Q(emp_mail__contains=emp_form.cleaned_data['emp_mail']) | Q(emp_number=emp_form.cleaned_data['emp_number'])) & Q(emp_role=emp_form.cleaned_data['emp_role']) & Q(active_status=1)).count()
                        if a == 0:
                            emp_form.save()
                            messages.info(request, "User Successfully Created ..!")
                            data = {
                                'status': 1,
                                'redirect': 'admins/0',
                            }
                            dump = json.dumps(data)
                        else:
                            data = {
                                'status': 4,
                                'redirect': 'admins/0',
                            }
                            dump = json.dumps(data)
                        return HttpResponse(dump, content_type='application/json')
                    except:
                        data = {
                            'status': 2,
                            'redirect': 'enter proper details',
                        }
                        dump = json.dumps(data)
                        return HttpResponse(dump, content_type='application/json')
                else:
                    data = {
                        'status': 3,
                        'redirect': 'enter all details',
                    }
                    dump = json.dumps(data)
                    return HttpResponse(dump, content_type='application/json')
                pos_emp = pos_employee.objects.filter((Q(emp_role__in=(1,4,5)))&Q(active_status=1))
                return render(request, 'admins.html', {'pos_emp':pos_emp})
            else:
                pos_emp = pos_employee.objects.filter((Q(emp_role__in=(1,4,5)))&Q(active_status=1))
                return render(request, 'admins.html', {'pos_emp':pos_emp})
        elif action == "2":
            id = request.POST['emp_id']
            if request.method == 'POST':
                pos_emp_edit = pos_employee.objects.get(id=id)
                old_emp_img = pos_emp_edit.emp_img
                edit_emp_form = pos_edit_employee_form(request.POST, request.FILES, instance = pos_emp_edit)
                if pos_emp_edit.active_status == '1':
                    if edit_emp_form.is_valid():
                        try:
                            a = pos_employee.objects.filter(Q(Q(emp_name__contains=edit_emp_form.cleaned_data['emp_name']) | Q(emp_mail__contains=edit_emp_form.cleaned_data['emp_mail']) | Q(emp_number=edit_emp_form.cleaned_data['emp_number'])) & Q(emp_role=edit_emp_form.cleaned_data['emp_role']) & Q(active_status=1) & ~Q(id=id)).count()
                            if a == 0:
                                edit_emp_form.save()
                                emp_arr = {
                                    "id": str(pos_emp_edit.id),
                                    "name": str(pos_emp_edit.emp_name),
                                    "age": str(pos_emp_edit.emp_age),
                                    "gender": str(pos_emp_edit.emp_gender),
                                    "dp": str(pos_emp_edit.emp_img),
                                    "address": str(pos_emp_edit.emp_address),
                                    "number": str(pos_emp_edit.emp_number),
                                    "mail": str(pos_emp_edit.emp_mail),
                                }
                                request.session['userArr']=emp_arr
                                messages.info(request, "User Details Successfully Updated ..!")
                                data = {
                                    'status': 1,
                                    'redirect': 'admins/0',
                                }
                                dump = json.dumps(data)
                            else:
                                data = {
                                    'status': 4,
                                    'redirect': 'admins/0',
                                }
                                dump = json.dumps(data)
                            return HttpResponse(dump, content_type='application/json')
                        except:
                            data = {
                                'status': 2,
                                'redirect': 'Enter Proper Details',
                            }
                            dump = json.dumps(data)
                            return HttpResponse(dump, content_type='application/json')
                    else:
                        data = {
                            'status': 3,
                            'redirect': 'Enter All Details',
                        }
                        dump = json.dumps(data)
                        return HttpResponse(dump, content_type='application/json')
                    pos_emp_edit = pos_employee.objects.filter(Q(emp_role__in=(1,4,5))&Q(active_status=1))
                    return render(request, 'admins.html', {'pos_emp_edit':pos_emp_edit})
            else:
                return render(request, 'admins.html')
        elif action == "3":
            id = request.POST['aid']
            pos_emp_delete_obj = pos_employee.objects.get(id=id)
            pos_emp_delete = pos_employee.objects.filter(id=id).update(active_status=0)
            messages.info(request, "User Successfully Deleted ..!")
            return HttpResponse(messages)
        else:
            pos_emp = pos_employee.objects.filter(Q(emp_role__in=(1,4,5)) & Q(active_status=1) & ~Q(id=1))
            return render(request, 'admins.html', {'pos_emp':pos_emp})
    else:
        return redirect('/index')

def change_password(request):
    if request.method == 'POST':
        emp_id = request.POST['emp_id']
        old_pass = request.POST['old_pass']
        new_pass = request.POST['new_pass']
        re_ent_pass = request.POST['re_new_pass']
        pos_employee_obj = pos_employee.objects.get(id=emp_id)
        if pos_employee_obj.emp_password == old_pass:
            if new_pass == re_ent_pass:
                pos_employee_objects = pos_employee.objects.filter(id=emp_id).update(emp_password=new_pass)
                return HttpResponse('1')
            else:
                return HttpResponse('2')
        else:
            return HttpResponse('3')
    else:
        return redirect('4')

    # /---- Dashboard Func ----/

def dashboard_inventory(request):
    arr = []
    arr1 = []
    arr2 = []
    arr3 = []
    daily_date = datetime.strptime(str(timezone.now().date()), '%Y-%m-%d').date()
    if 'user_id' in request.session and request.session['user_role'] == '1':
        # First Row Objects

        total_purchase_amt = 0
        order_count = pos_inv_stock_order.objects.filter(Q(order_action=3) & Q(order_date__gt=daily_date)).count()
        purchase_count = pos_inv_purchase_details.objects.filter(purchase_date__gt=daily_date).count()
        total_purchase_amt = sum(float(i.purchase_amount) for i in pos_inv_purchase_details.objects.filter(purchase_date__gt=daily_date))
        kitchen_count = pos_inv_kitchen_delivery.objects.filter(Q(kitchen_order_action=3) & Q(kitchen_order_date__gt=daily_date)).count()

        # Second Row Objects

        for j in pos_inv_kitchen_delivery.objects.filter(Q(kitchen_order_date__gt=daily_date) & Q(kitchen_order_action=3)):
            for k in json.loads(j.kitchen_order_arr):
                data = {
                    'id': k['id'],
                    'units_no': k['units_no'],
                    'units': k['units'],
                }
                arr.append(data)
                arr1.append(k['id'])
        for l in set(arr1):
            qty_cnt = 0
            for m in arr:
                if int(l) == int(m['id']):
                    qty_cnt += float(m['units_no'])
                    temp = m['units']
            data = {
                'id': int(l),
                'units_no': str(qty_cnt),
                'units': str(temp),
            }
            arr2.append(data)
        for n in arr2:
            price_cnt = 0
            for o in pos_inv_product_stock.objects.filter(stock_entry_status=1):
                if int(n['id']) == o.stock_product_id.product_id:
                    price_cnt = float(n['units_no']) * float(o.stock_price)
            data = {
                'id': int(n['id']),
                'price': float(price_cnt),
                'units_no': float(n['units_no']),
            }
            arr3.append(data)

        total_order_qty = 0
        total_recieved_qty = 0
        for p in pos_inv_stock_order.objects.filter(Q(order_action=3) & Q(order_date__gt=daily_date)):
            for q in json.loads(p.order_arr):
                total_order_qty += float(q['units_no'])
        for r in pos_inv_purchase_details.objects.filter(Q(purchase_date__gt=daily_date)):
            for s in json.loads(r.purchase_order_arr):
                total_recieved_qty += float(s['units_no'])

        # Third Row Objects

        min_stock = []
        for i in pos_inv_product_stock.objects.filter(stock_entry_status=1):
            if int(i.stock_min_val) > float(i.stock_val) :
                temp1 = pos_inv_product.objects.get(product_id=i.stock_product_id.product_id)
                temp2 = pos_inv_units.objects.get(unit_id=temp1.product_units_id)
                temp = temp2.unit_name_short
                data = {
                    'name': i.stock_product_id.product_name,
                    'min_val': i.stock_min_val,
                    'stock_val': i.stock_val,
                    'stock_unit': temp,
                }
                min_stock.append(data)

        # Third Row Objects for Current Stock Qty

        current_stock_qty = 0
        current_stock_val = 0
        for i in pos_inv_product_stock.objects.all():
            current_stock_qty += float(i.stock_val)
            temp_stock_val = float(i.stock_val) * float(i.stock_price)
            current_stock_val += temp_stock_val

        # Third Row Objects for Minimise Report
        current_month_amt = 0
        previous_month_amt = 0
        current_month = daily_date.strftime('%m')
        current_year = daily_date.strftime('%Y')
        set_current_month = datetime.strptime(str(current_year+'-'+current_month+'-1'), "%Y-%m-%d").date()
        add_current_month = set_current_month + relativedelta(months=1)
        for i in pos_inv_purchase_details.objects.filter(purchase_date__range=(set_current_month, add_current_month)):
            current_month_amt += float(i.purchase_amount)

        sub_current_month = set_current_month - relativedelta(months=1)
        get_last_date = set_current_month - timedelta(days=1)
        for j in pos_inv_purchase_details.objects.filter(purchase_date__range=(sub_current_month, get_last_date)):
            previous_month_amt += float(j.purchase_amount)

        current_month_total_order_qty = 0
        for k in pos_inv_stock_order.objects.filter(order_date__range=(set_current_month, add_current_month)):
            for l in json.loads(k.order_arr):
                current_month_total_order_qty += float(l['units_no'])

        last_month_total_order_qty = 0
        for k in pos_inv_stock_order.objects.filter(order_date__range=(sub_current_month, get_last_date)):
            for l in json.loads(k.order_arr):
                last_month_total_order_qty += float(l['units_no'])

        context = {
            'min_stock': min_stock,
            'current_stock_qty': current_stock_qty,
            'current_stock_val': current_stock_val,
            'kitchen_count': kitchen_count,
            'order_count': order_count,
            'purchase_count': purchase_count,
            'total_purchase_amt': total_purchase_amt,
            'total_order_qty': total_order_qty,
            'total_recieved_qty': total_recieved_qty,
            'product_cnt': arr2,
            'product_amt': arr3,
            'stock_obj': pos_inv_product_stock.objects.filter(stock_entry_status=1),
            'current_month_amt': current_month_amt,
            'previous_month_amt': previous_month_amt,
            'current_month_total_order_qty': current_month_total_order_qty,
            'last_month_total_order_qty': last_month_total_order_qty,
        }
        return render(request, 'dashboard.html', context)
    else:
        return redirect('/index')

def pos_inv_category_func(request, id):
    cat_section = id
    if 'user_id' in request.session and request.session['user_role'] == '1':
        if cat_section == '0':
            pos_inv_cat_obj = pos_inv_category.objects.filter(category_status=1)
            pos_inv_units_obj = pos_inv_units.objects.filter(unit_status=1)
            context = {
                'pos_inv_cat_obj': pos_inv_cat_obj,
                'pos_inv_units_obj': pos_inv_units_obj,
            }
            return render(request, 'invCategory.html', context)
        if cat_section == '1':
            if request.method == "POST":
                inv_cat_form = inv_category_form(request.POST, request.FILES)
                if inv_cat_form.is_valid():
                    try:
                        inv_cat_form.save()
                        messages.info(request, "Category Successfully Created ..!")
                        return HttpResponse('1')
                    except:
                        pass
                        return HttpResponse('2')
                else:
                    return HttpResponse('3')
            else:
                return HttpResponse('addfail')
        if cat_section == '2':
            if request.method == 'POST':
                edit_inv_cat_form = inv_category_form(request.POST, request.FILES, instance=pos_inv_category.objects.get(category_id=request.POST['cat_id']))
                if edit_inv_cat_form.is_valid():
                    try:
                        edit_inv_cat_form.save()
                        messages.info(request, "Category Successfully Updated ..!")
                        return HttpResponse('1')
                    except:
                        pass
                        return HttpResponse('2')
                else:
                    return HttpResponse('3')
            else:
                return HttpResponse('editfail')
        if cat_section == '3':
            if request.method == 'POST':
                delete_category_obj = pos_inv_category.objects.filter(category_id=request.POST['del_cat']).update(category_status=0)
                messages.info(request, "Category Successfully Deleted ..!")
                return HttpResponse('1')
            else:
                return HttpResponse('deletefail')
    else:
        return redirect('/index')

def pos_inv_product_func(request, id):
    product_section = id
    if 'user_id' in request.session and request.session['user_role'] == '1':
        pos_inv_cat_obj = pos_inv_category.objects.filter(category_status=1)
        pos_inv_units_obj = pos_inv_units.objects.all()
        if product_section == '0':
            context = {
                'pos_inv_cat_obj': pos_inv_cat_obj,
                'pos_inv_units_obj': pos_inv_units_obj,
                'pos_inv_pro_obj': pos_inv_product.objects.filter(product_status=1),
                'pos_inv_stock_entry_obj': pos_inv_product_stock.objects.filter(stock_entry_status=1),
            }
            return render(request, 'invProduct.html', context)
        if product_section == '1':
            if request.method == "POST":
                inv_pro_form = inv_product_form(request.POST, request.FILES)
                if inv_pro_form.is_valid():
                    try:
                        inv_pro_form.save()
                        a = pos_inv_product.objects.all().last()
                        add_stock_entry_obj = pos_inv_product_stock(stock_product_id_id=a.product_id, stock_min_val=str(request.POST['stock_min_val']), stock_entry_status=1, stock_val=0)
                        add_stock_entry_obj.save()
                        messages.info(request, "Product Successfully Created ..!")
                        return HttpResponse('1')
                    except:
                        pass
                        return HttpResponse('2')
                else:
                    return HttpResponse('3')
            else:
                return HttpResponse('addfail')
        if product_section == '2':
            if request.method == 'POST':
                edit_inv_pro_form = inv_product_form(request.POST, request.FILES, instance=pos_inv_product.objects.get(product_id=request.POST['pro_id']))
                if edit_inv_pro_form.is_valid():
                    # return HttpResponse(inv_pro_form.errors.as_data())
                    try:
                        edit_inv_pro_form.save()
                        messages.info(request, "Product Successfully Updated ..!")
                        add_stock_entry_obj = pos_inv_product_stock.objects.filter(stock_product_id_id=request.POST['pro_id']).update(stock_min_val=str(request.POST['stock_min_val']))
                        return HttpResponse('1')
                    except:
                        pass
                        return HttpResponse('2')
                else:
                    return HttpResponse('3')
            else:
                return HttpResponse('editfail')
        if product_section == '3':
            if request.method == 'POST':
                delete_product_obj = pos_inv_product.objects.filter(product_id=request.POST['del_pro']).update(product_status=0)
                add_stock_entry_obj = pos_inv_product_stock.objects.filter(stock_product_id_id=request.POST['del_pro']).update(stock_entry_status=0)
                messages.info(request, "Product Successfully Deleted ..!")
                return HttpResponse('1')
            else:
                return HttpResponse('deletefail')
    else:
        pos_inv_cat_obj = pos_inv_category.objects.filter(category_status=1)
        pos_inv_units_obj = pos_inv_units.objects.all()
        context = {
            'pos_inv_cat_obj': pos_inv_cat_obj,
            'pos_inv_units_obj': pos_inv_units_obj,
            'pos_inv_pro_obj': pos_inv_product.objects.filter(product_status=1),
            'pos_inv_stock_entry_obj': pos_inv_product_stock.objects.filter(stock_entry_status=1),
        }
        return render(request, 'invProduct.html', context)

def pos_inv_supplier_func(request, id):
    supplier_section = id
    if 'user_id' in request.session and request.session['user_role'] == '1':
        if supplier_section == '0':
            context = {
                'pos_inv_sup_obj': pos_inv_supplier.objects.all(),
            }
            return render(request, 'invSupplier.html', context)
        if supplier_section == '1':
            if request.method == "POST":
                inv_sup_form = inv_supplier_form(request.POST, request.FILES)
                if inv_sup_form.is_valid():
                    try:
                        # return HttpResponse(request.POST['supplier_image'])
                        inv_sup_form.save()
                        messages.info(request, "Supplier Created Successfully ..!")
                        return HttpResponse('1')
                    except:
                        pass
                        return HttpResponse('2')
                else:
                    return HttpResponse('3')
            else:
                return HttpResponse('addfail')
            return render(request, 'invProduct.html', context)
        if supplier_section == '2':
            if request.method == 'POST':
                edit_inv_sup_form = inv_supplier_form(request.POST, request.FILES, instance=pos_inv_supplier.objects.get(supplier_id=request.POST['sup_id']))
                if edit_inv_sup_form.is_valid():
                    try:
                        edit_inv_sup_form.save()
                        messages.info(request, "Supplier Details Updated Successfully ..!")
                        return HttpResponse('1')
                    except:
                        pass
                        return HttpResponse('2')
                else:
                    return HttpResponse('3')
            else:
                return HttpResponse('editfail')
        if supplier_section == '3':
            if request.method == 'POST':
                delete_supplier_obj = pos_inv_supplier.objects.filter(supplier_id=request.POST['del_sup']).update(supplier_status=0)
                messages.info(request, "Supplier Deleted Successfully ..!")
                return HttpResponse('1')
            else:
                return HttpResponse('deletefail')
    else:
        context = {
                'pos_inv_sup_obj': pos_inv_supplier.objects.all(),
            }
        return render(request, 'invSupplier.html', context)

def pos_inv_stock_order_func(request):
    if 'inv_v_arr' in request.session:
        del request.session['inv_v_arr']
    if 'order_id' in request.session:
        del request.session['order_id']
    if 'chq' in request.session:
        del request.session['chq']
    date = datetime.strptime(str(timezone.now().date()), "%Y-%m-%d").date()
    recieved_arr = []
    ordered_arr = []
    for i in pos_inv_stock_order.objects.all():
        for j in pos_inv_purchase_details.objects.filter(purchase_order_no_id=str(i.order_id)):
            for k in json.loads(j.purchase_order_arr):
                data = {
                    'purchase_id': i.order_id,
                    'id': str(k['id']),
                    'name': str(k['name']),
                    'units_no': str(k['units_no']),
                    'units': str(k['units']),
                }
                recieved_arr.append(data)
    for l in pos_inv_stock_order.objects.all():
        for m in json.loads(l.order_arr):
            data = {
                'order_id': l.order_id,
                'order_date': l.order_date,
                'order_number': l.order_number,
                'id': str(m['id']),
                'name': str(m['name']),
                'units_no': str(m['units_no']),
                'units': str(m['units']),
            }
            ordered_arr.append(data)
    context = {
        'pos_inv_orderd_obj': pos_inv_stock_order.objects.filter(Q(order_action__in=(0,1))),
        'pos_inv_supplier_obj': pos_inv_supplier.objects.all(),
        'pos_inv_orders': pos_inv_stock_order.objects.filter(Q(order_action=2)),
        'recieved_arr': recieved_arr,
        'ordered_arr': ordered_arr,
    }
    return render(request, 'stockOrder.html', context)

def pos_inv_order_func(request):
    context = {
        'pos_inv_category_obj': pos_inv_category.objects.all(),
        'pos_inv_product_obj': pos_inv_product.objects.filter(product_status=1),
        'pos_inv_stock_entry_obj': pos_inv_product_stock.objects.filter(stock_entry_status=1),
    }
    return render(request, 'invOrder.html', context)

def order_arr_func(request):
    inv_v_arr = []
    check = 0
    if 'inv_v_arr' in request.session:
        inv_v_arr.extend(request.session['inv_v_arr'])
        for i in inv_v_arr:
            if i['id'] == request.POST['order_id']:
                check = 1
                return HttpResponse(check)
    if check > 0:
        return HttpResponse('1')
    else:
        for i in pos_inv_product.objects.filter(product_id=request.POST['order_id']):
            data = {
                'id': str(i.product_id),
                'name': str(i.product_name),
                'units': str(i.product_units.unit_name_short),
                'units_no': float('0'),
                'status': str('1'),
                'price': float('0'),
            }
            inv_v_arr.append(data)
            request.session['inv_v_arr'] = inv_v_arr
        return HttpResponse(json.dumps(data), content_type='application/json')

def order_update_unit_func(request):
    if 'inv_v_arr' in request.session:
        inv_v_arr = []
        inv_v_arr.extend(request.session['inv_v_arr'])
        for i in inv_v_arr:
            if i['id'] == request.POST['order_update_id']:
                i['units_no'] = float(request.POST['unit_val'])
                request.session['inv_v_arr'] = inv_v_arr
                return HttpResponse(request.session['inv_v_arr'])

def create_order(request, id, val):
    inv_v_arr = []
    date = datetime.strptime(str(timezone.now().date()), "%Y-%m-%d").date()
    if id == '0':
        if 'inv_v_arr' in request.session:
            inv_v_arr.extend(request.session['inv_v_arr'])
            a = pos_inv_stock_order.objects.filter(order_date__gt=str(date)).last()
            if pos_inv_stock_order.objects.filter(order_date__gt=str(date)).exists():
                last_order_number_obj = pos_inv_stock_order.objects.get(order_id=a.order_id)
                order_text_obj = str(last_order_number_obj.order_number)
                last_id_bill_number = int(order_text_obj[6:None])
            else:
                last_id_bill_number = 0
            last_id_bill_number += 1
            order_text_number = str('OR') + str(date.strftime('%m%d')) + str(str(last_id_bill_number).zfill(3))
            if val == '0':
                stock_order_obj = pos_inv_stock_order(order_arr=json.dumps(inv_v_arr), order_number=str(order_text_number), order_action=0)
                stock_order_obj.save()
                messages.info(request, 'Order Successfully Saved ..!')
                return redirect('/pos_inv_stock_order')
            else:
                stock_order_obj = pos_inv_stock_order(order_arr=json.dumps(inv_v_arr), order_number=str(order_text_number), order_action=1)
                stock_order_obj.save()
                messages.info(request, 'Order Successfully Sent ..!')
                return redirect('/confirm_purchase/'+str(stock_order_obj.order_id)+'/')
        else:
            return HttpResponse('no session in inv_v_arr')
    else:
        if 'inv_v_arr' in request.session:
            inv_v_arr.extend(request.session['inv_v_arr'])
            if val == '0':
                get_order_arr_obj = pos_inv_stock_order.objects.filter(order_id=id).update(order_arr=json.dumps(inv_v_arr), order_action=0)
                messages.info(request, 'Order Successfully Updated ..!')
                return redirect('/pos_inv_stock_order')
            else:
                get_order_arr_obj = pos_inv_stock_order.objects.filter(order_id=id).update(order_arr=json.dumps(inv_v_arr), order_action=1)
                messages.info(request, 'Order Successfully Sent ..!')
                return redirect('/confirm_purchase/'+id+'/')

def confirm_purchase(request, order):
    arr = pos_inv_stock_order.objects.get(order_id=order)
    ids=[]
    for o in json.loads(arr.order_arr):
        ids.append(int(o['id']))
    data = {
        'order_id':arr,
        'order_arr':json.loads(arr.order_arr),
        'pos_inv_product_obj': pos_inv_product.objects.filter(Q(product_status=1) & Q(product_id__in=ids)),
        'pos_inv_supplier_obj': pos_inv_supplier.objects.filter(supplier_status=1)
    }
    return render(request, 'confirmPurchase.html', data)

def pos_inv_edit_order_func(request, id):
    inv_v_arr = []
    request.session['order_id'] = int(id)
    if 'inv_v_arr' in request.session:
        inv_v_arr.extend(request.session['inv_v_arr'])
    else:
        order_arr_obj = pos_inv_stock_order.objects.get(order_id=request.session['order_id'])
        for i in json.loads(order_arr_obj.order_arr):
            data = {
                'id': str(i['id']),
                'name': str(i['name']),
                'units': str(i['units']),
                'units_no': float(i['units_no']),
                'status': str(i['status']),
                'price': float('0'),
            }
            inv_v_arr.append(data)
        request.session['inv_v_arr'] = inv_v_arr
    context = {
        'pos_inv_category_obj': pos_inv_category.objects.all(),
        'pos_inv_product_obj': pos_inv_product.objects.filter(product_status=1),
        'pos_inv_edit_stock_order': inv_v_arr,
        'pos_inv_stock_entry_obj': pos_inv_product_stock.objects.filter(stock_entry_status=1),
    }
    return render(request, 'invOrder.html', context)


def pos_inv_del_order_func(request):
    inv_v_arr = []
    if 'inv_v_arr' in request.session:
        inv_v_arr.extend(request.session['inv_v_arr'])
    for i in inv_v_arr:
        if i['id'] == request.POST['order_delete_id']:
            # return HttpResponse(request.POST['order_delete_id'])
            data = {
                'id': str(i['id']),
                'name': str(i['name']),
                'units': str(i['units']),
                'units_no': float(i['units_no']),
                'status': str(i['status']),
                'price': float('0'),
            }
            inv_v_arr.remove(data)
            request.session['inv_v_arr'] = inv_v_arr
    if request.POST['val']=='1':
        request.session['inv_v_arr'] = inv_v_arr
    else:
        del_order_arr_obj = pos_inv_stock_order.objects.filter(order_id=request.session['order_id']).update(order_arr=json.dumps(inv_v_arr))
    return HttpResponse(1)

def pos_inv_send_order_func(request, id):
    if request.method == "POST":
        supplier_mail = request.POST['s_mail']
        supplier_number = request.POST['s_number']
        supplier_pdf = request.POST['s_pdf']
        supplier_mail_obj = pos_inv_supplier.objects.get(supplier_id=str(request.POST['order_supplier_id']))
        c = 0
        update_order_sender_obj = pos_inv_stock_order.objects.filter(order_id=id).update(order_supplier=supplier_mail_obj.supplier_id, ordered_by=request.session['user_id'], order_action=2)
        # return HttpResponse(supplier_mail_obj.supplier_id)
        if supplier_mail == '1':
            a = mail_func(request, id, supplier_mail_obj.supplier_id)
        if supplier_number == '1':
            b = pdf_func(request, id, supplier_mail_obj.supplier_id)
        if supplier_pdf == '1':
            c = pdf_func(request, id, supplier_mail_obj.supplier_id)
            return HttpResponse(c)
        return HttpResponse('1')
    else:
        return HttpResponse("2")

def mail_func(request, id, sup_obj):
    from django.core.mail import EmailMessage
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Spacer, Paragraph, Table, TableStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import cm
    from reportlab.lib.enums import TA_CENTER,TA_LEFT, TA_JUSTIFY, TA_RIGHT
    from reportlab.lib import colors
    from reportlab.platypus.flowables import HRFlowable
    count = 0
    r_buffer = BytesIO()
    stylesheet = getSampleStyleSheet()
    elements = []
    clr=colors.black

    doc = SimpleDocTemplate(r_buffer, pagesize=(12*cm, 20*cm), rightMargin=0, leftMargin=0, topMargin=10, bottomMargin=10)

    hotel_name = ParagraphStyle('parrafos', alignment = TA_CENTER, fontSize = 14, fontName="Times-Roman", textColor=clr)
    th = ParagraphStyle('parrafos', alignment = TA_CENTER, fontSize = 12, fontName="Times-Roman", textColor=clr)
    td = ParagraphStyle('parrafos', alignment = TA_CENTER, fontSize = 10, fontName="Times-Roman", textColor=clr)
    td_left = ParagraphStyle('parrafos', alignment = TA_LEFT, fontSize = 10, fontName="Times-Roman", textColor=clr)
    td_right = ParagraphStyle('parrafos', alignment = TA_RIGHT, fontSize = 10, fontName="Times-Roman", textColor=clr)

    a = pos_inv_stock_order.objects.get(order_id=id)
    sup_name = str('Supplier : ') + str(a.order_supplier_id)
    order_date = datetime.strptime(str(a.order_date.date()), "%Y-%m-%d").date()
    # return HttpResponse(a.order_supplier)
    data = [
        [Paragraph(str(a.order_number),td)],
        [Paragraph(str(sup_name),td_left), '',  Paragraph(str(order_date),td_right), ''],
        [Paragraph(u"No",td),  Paragraph(u"Items",td),  Paragraph(u"qty",td),  Paragraph(u"units",td)],
    ]
    for i in json.loads(a.order_arr):
        count+=1
        unit_txt = str(i['units_no']) + str(' ') + str(i['units'])
        data.append([Paragraph(str(count),td), Paragraph(str(i['name']),td), Paragraph(str(i['units_no']),td), Paragraph(str(i['units']),td)])
    table = Table(data,colWidths=[1 * cm, 5 * cm, 2 * cm, 3 * cm])
    table.setStyle(TableStyle(
        [
            ('GRID', (0, 2), (3, count+2), 0, colors.black),
            ('SPAN', (0, 0), (3, 0)),
            ('SPAN', (0, 1), (1, 1)),
            ('SPAN', (2, 1), (3, 1)),
            # ('SPAN', (1, 1), (3, 0)),
            # ('LINEBELOW', (0,1), (2,1), 0.5, clr, None, (2.85,1.2)),
            # ('LINEBELOW', (0,2), (2,2), 0.5, clr, None, (2.85,1.2)),
        ]
    ))
    elements.append(table)
    doc.build(elements)
    result = r_buffer.getvalue()
    r_buffer.close()
    supplier_mail_func_obj = pos_inv_supplier.objects.get(supplier_id=sup_obj)
    email = EmailMessage('Subject here', 'Here is the message.', 'vignesh@chandhniinfotech.com', [supplier_mail_func_obj.supplier_mail])
    email.attach('document.pdf', result, 'application/pdf')
    email.send()
    return HttpResponse(supplier_mail_func_obj.supplier_mail)

def pdf_func(request, id, sup_obj):
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Spacer, Paragraph, Table, TableStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import cm
    from reportlab.lib.enums import TA_CENTER,TA_LEFT, TA_JUSTIFY, TA_RIGHT
    from reportlab.lib import colors
    from reportlab.platypus.flowables import HRFlowable
    count = 0
    r_buffer = BytesIO()
    stylesheet = getSampleStyleSheet()
    elements = []
    clr=colors.black

    doc = SimpleDocTemplate(r_buffer, pagesize=(12*cm, 20*cm), rightMargin=0, leftMargin=0, topMargin=10, bottomMargin=10)

    hotel_name = ParagraphStyle('parrafos', alignment = TA_CENTER, fontSize = 14, fontName="Times-Roman", textColor=clr)
    th = ParagraphStyle('parrafos', alignment = TA_CENTER, fontSize = 12, fontName="Times-Roman", textColor=clr)
    td = ParagraphStyle('parrafos', alignment = TA_CENTER, fontSize = 10, fontName="Times-Roman", textColor=clr)
    td_left = ParagraphStyle('parrafos', alignment = TA_LEFT, fontSize = 10, fontName="Times-Roman", textColor=clr)
    td_right = ParagraphStyle('parrafos', alignment = TA_RIGHT, fontSize = 10, fontName="Times-Roman", textColor=clr)

    a = pos_inv_stock_order.objects.get(order_id=id)
    sup_name = str('Supplier : ') + str(a.order_supplier.store_name)
    order_date = str('Date : ') + str(datetime.strptime(str(a.order_date.date()), "%Y-%m-%d").date())
    data = [
        [Paragraph(str(a.order_number),td)],
        [Paragraph(str(sup_name),td_left), '',  Paragraph(str(order_date),td_right), ''],
        [Paragraph(u"No",td),  Paragraph(u"Items",td),  Paragraph(u"qty",td),  Paragraph(u"units",td)],
    ]
    for i in json.loads(a.order_arr):
        count+=1
        unit_txt = str(i['units_no']) + str(' ') + str(i['units'])
        data.append([Paragraph(str(count),td), Paragraph(str(i['name']),td), Paragraph(str(i['units_no']),td), Paragraph(str(i['units']),td)])
    table = Table(data,colWidths=[1 * cm, 5 * cm, 2 * cm, 3 * cm])
    table.setStyle(TableStyle(
        [
            ('GRID', (0, 2), (3, count+2), 0, colors.black),
            ('SPAN', (0, 0), (3, 0)),
            ('SPAN', (0, 1), (1, 1)),
            ('SPAN', (2, 1), (3, 1)),
            # ('SPAN', (1, 1), (3, 0)),
            # ('LINEBELOW', (0,1), (2,1), 0.5, clr, None, (2.85,1.2)),
            # ('LINEBELOW', (0,2), (2,2), 0.5, clr, None, (2.85,1.2)),
        ]
    ))
    elements.append(table)
    doc.build(elements)
    result = r_buffer.getvalue()
    r_buffer.close()
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition']='attachment; filename="bill.pdf"'
    response.write(result)
    return response

def pos_inv_purchase_func(request):
    if 'user_id' in request.session:
        product_arr = []
        arr = []
        a = []
        b=[]
        if 'ordered_by_arr' in request.session:
            del request.session['ordered_by_arr']
        if 'total_amt' in request.session:
            del request.session['total_amt']
        for i in pos_inv_stock_order.objects.all():
            for j in json.loads(i.order_arr):
                if str(j['status']) == '1':
                    arr.append(i.order_id)
        for i in pos_inv_purchase_details.objects.all():
            b.append(i)
            for j in json.loads(i.purchase_order_arr):
                st=0
                for kk in j.keys():
                    st = j[kk]
                    break
                if j['units_no'] != float(0):
                    # return HttpResponse(float(j['units_no']))
                    data = {
                        'id': str(j['id']),
                        'name': str(j['name']),
                        'units_no': float(j['units_no']),
                        'units': str(j['units']),
                        'price': float(j['price']),
                        'purchase_id': i.purchase_id,
                    }
                    product_arr.append(data)
        amt = []
        for m in pos_inv_purchase_details.objects.all():
            a = 0
            for n in pos_inv_bill_payment.objects.all():
                if n.payment_bill_number_id == m.purchase_id:
                    a += int(n.payment_amount)
            data = {
                'amt': a,
                'id': m.purchase_id,
            }
            amt.append(data)
        for p in pos_inv_purchase_details.objects.all():
            for q in amt:
                if q['id'] == p.purchase_id:
                    if str(p.purchase_amount) == str(q['amt']):
                        pos_inv_purchase_details.objects.filter(purchase_id=q['id']).update(purchase_settlement=2)

        context = {
            'purchase_obj': pos_inv_purchase_details.objects.filter(purchase_statement=1),
            'account_details_obj': pos_inv_supplier_account_details.objects.filter(account_status=1),
            'payment_obj': pos_inv_bill_payment.objects.all(),
            'product_arr': product_arr,
            'paid_amt': amt,
            'page': 1,
        }
        return render(request, 'invPurchase.html', context)
    else:
        return redirect('/index')

def add_purchase_entry_func(request):
    arr = []
    order_arr = []
    purchase_arr = []
    pending_arr = []
    pending_arr_id = []
    for i in pos_inv_stock_order.objects.filter(Q(order_action=3)):
        for j in json.loads(i.order_arr):
            if str(j['status']) == '1':
                arr.append(i.order_id)
    for i in pos_inv_stock_order.objects.filter(Q(order_action=3)):
        for j in json.loads(i.recieved_arr):
            data = {
                'order_id': i.order_id,
                'order_no': i.order_number,
                'order_date': i.order_date,
                'id': str(j['id']),
                'name': str(j['name']),
                'units_no': float(j['units_no']),
                'units': str(j['units']),
                'price': str(j['price']),
                'status': str(j['status']),
            }
            purchase_arr.append(data)
    for i in pos_inv_stock_order.objects.filter(Q(order_action=3)):
        for j in json.loads(i.order_arr):
            data = {
                'order_id': i.order_id,
                'order_no': i.order_number,
                'order_date': i.order_date,
                'id': str(j['id']),
                'name': str(j['name']),
                'units_no': float(j['units_no']),
                'units': str(j['units']),
                'price': str(j['price']),
                'status': str(j['status']),
            }
            order_arr.append(data)
    for i in order_arr:
        for j in purchase_arr:
            if j['order_id'] == i['order_id']:
                if j['id'] == i['id']:
                    if float(j['units_no']) < float(i['units_no']):
                        temp = float(i['units_no']) - float(j['units_no'])
                        data = {
                            'order_id': i['order_id'],
                            'order_no': i['order_no'],
                            'id': str(j['id']),
                            'name': str(j['name']),
                            'units_no': float(temp),
                            'units': str(j['units']),
                            'price': float(0),
                            'status': str(j['status']),
                        }
                        data1 = {
                            'order_id': i['order_id'],
                            'order_no': i['order_no'],
                        }
                        pending_arr.append(data)
                        pending_arr_id.append(data1)
    get_pending_visible_days = pos_inv_settings.objects.get(id=1)
    date = datetime.strptime(str(timezone.now().date()), "%Y-%m-%d").date()
    set_format = set()
    set_arr = []
    c=[]
    for d in pending_arr_id:
        diff=0
        visiblity=0
        get_purchase_date = pos_inv_purchase_details.objects.filter(purchase_order_no_id=d['order_id'])
        for i in get_purchase_date:
            set_date = datetime.strptime(str(i.purchase_date.date()), "%Y-%m-%d").date()
            diff=date-set_date
            diff=diff.days
            visiblity = int(get_pending_visible_days.pending_order_visibility)
            if int(diff) <= int(visiblity):
                t = tuple(d.items())
                if t not in set_format:
                    set_format.add(t)
                    set_arr.append(d)
    request.session['pending_arr'] = pending_arr
    context = {
        'ordered_obj': pos_inv_stock_order.objects.filter(Q(order_action=2) | Q(order_id__in=arr)),
        'page': 2,
        'pending_arr': pending_arr,
        'set_arr': set_arr,
    }
    return render(request, 'invPurchase.html', context)

def pos_inv_purchase_return_func(request, id):
    if 'user_id' in request.session:
        arr = []
        i = pos_inv_purchase_details.objects.get(purchase_id=id)
        for j in json.loads(i.purchase_order_arr):
            if j['units_no'] != float(0):
                arr.append(j['id'])
        context = {
            'purchase_bill': i,
            'purchase_products': json.loads(i.purchase_order_arr),
            'product_obj': pos_inv_product.objects.filter(product_id__in=arr),
            'stock_obj': pos_inv_product_stock.objects.filter(Q(stock_entry_status=1) & Q(stock_product_id__in=arr)),
            'page': 3,
        }
        return render(request, 'invPurchase.html', context)
    else:
        return redirect('/index')

def pos_inv_purchase_return_save(request, id):
    if request.method == 'POST':
        return_arr = []
        purchase_arr = []
        r_id = request.POST.getlist('purProId[]')
        r_name = request.POST.getlist('purProName[]')
        r_unit = request.POST.getlist('purProUnit[]')
        r_unit_name = request.POST.getlist('purProUnitName[]')
        r_price = request.POST.getlist('purProPrice[]')
        r_amo = request.POST.getlist('purProAmount[]')
        total_amt = sum(int(k) for k in r_amo)
        for i in range(0, len(r_id)):
            data = {
                'id': str(r_id[i]),
                'name': str(r_name[i]),
                'units_no': float(r_unit[i]),
                'units': str(r_unit_name[i]),
                'price': float(r_price[i]),
                'status': (0),
            }
            return_arr.append(data)
        i = pos_inv_purchase_details.objects.get(Q(purchase_id=id) & Q(purchase_statement=1))
        # reduce_purchase_amt = 0
        # if total_amt < i.purchase_amount:
        #     reduce_purchase_amt = float(i.purchase_amount) - float(total_amt)
        # elif total_amt == i.purchase_amount:
        #     reduce_purchase_amt = 0

        for m in json.loads(i.purchase_order_arr):
            for j in return_arr:
                if j['id'] == m['id']:
                    if m['units_no'] > j['units_no']:
                        units_no = m['units_no'] - j['units_no']
                    else:
                        units_no = 0
                else:
                    units_no = m['units_no']
                data = {
                    'id': str(m['id']),
                    'name': str(m['name']),
                    'units_no': float(units_no),
                    'units': str(m['units']),
                    'price': float(m['price']),
                    'status': str(m['status']),
                }
                purchase_arr.append(data)
        obj = pos_inv_purchase_details(purchase_bill_number=str(i.purchase_bill_number) ,purchase_bill_date=str(timezone.now()) ,purchase_order_arr=json.dumps(return_arr) ,purchase_order_no_id=i.purchase_order_no.order_id ,purchase_order_supplier_id=i.purchase_order_supplier.supplier_id ,purchase_SGST= 0,purchase_CGST= 0,purchase_discount= 0,purchase_amount=float(total_amt) ,purchase_entered_by_id=request.session['user_id'] ,purchase_settlement=None ,purchase_statement=0)
        obj.save()
        # pos_inv_purchase_details.objects.filter(Q(purchase_id=id) & Q(purchase_statement=1)).update(purchase_amount=reduce_purchase_amt)
        # a = pos_inv_purchase_details.objects.filter(purchase_id=id).update(purchase_order_arr=json.dumps(purchase_arr))
        for k in return_arr:
            sum_obj = 0
            stock_obj = pos_inv_product_stock.objects.get(stock_product_id_id=k['id'])
            sum_val = stock_obj.stock_val
            if float(sum_val) > float(k['units_no']):
                sum_obj = float(sum_val) - float(k['units_no'])
            else:
                sum_obj = float(0)
            pos_inv_product_stock.objects.filter(stock_product_id_id=int(k['id'])).update(stock_val=int(sum_obj))
        return HttpResponse('1')

def order_show_func(request, id):
    inv_p_arr = []
    ordered_by_arr = []
    if request.method == 'POST':
        get_order_obj = pos_inv_stock_order.objects.get(Q(order_id=id))
        data_order = {
            'order_by': str(get_order_obj.order_supplier.store_name),
            'order_no': str(get_order_obj.order_number),
            'order_id': str(get_order_obj.order_id),
            'order_by_id': str(get_order_obj.order_supplier_id),
        }
        ordered_by_arr.append(data_order)
        request.session['ordered_by_arr'] = ordered_by_arr
        if request.POST['a'] == '1':
            for i in json.loads(get_order_obj.order_arr):
                if i['status'] == '1':
                    data = {
                        'id': str(i['id']),
                        'name': str(i['name']),
                        'units_no': float(i['units_no']),
                        'units': str(i['units']),
                        'price': float(i['price']),
                        'status': str(i['status']),
                    }
                    inv_p_arr.append(data)
            request.session['inv_p_arr'] = inv_p_arr
            total_amt=0
            amt=0
            for i in inv_p_arr:
                amt = float(i['units_no'])*float(i['price'])
                total_amt = total_amt + amt
            # total_amt = sum(float(i['price']))
            request.session['total_amt'] = total_amt
            return HttpResponse(inv_p_arr)
        else:
            a = []
            if 'pending_arr' in request.session:
                a.extend(request.session['pending_arr'])
            for i in a:
                if int(i['order_id']) == int(id):
                    data = {
                        'id': str(i['id']),
                        'name': str(i['name']),
                        'units_no': float(i['units_no']),
                        'units': str(i['units']),
                        'price': float(0),
                        'status': str(1),
                    }
                    inv_p_arr.append(data)
            request.session['inv_p_arr'] = inv_p_arr
            total_amt=0
            amt=0
            for i in inv_p_arr:
                amt = float(i['units_no'])*float(i['price'])
                total_amt = total_amt + amt
            # total_amt = sum(float(i['price']))
            request.session['total_amt'] = total_amt
            return HttpResponse(inv_p_arr)
    else:
        return HttpResponse('2')

def order_show_update_func(request):
    if request.method == 'POST':
        inv_p_arr = []
        update_arr = []
        if 'inv_p_arr' in request.session:
            inv_p_arr.extend(request.session['inv_p_arr'])
        if request.POST['gn_val'] == '1':
            for i in inv_p_arr:
                if i['id'] == request.POST['product_id']:
                    i['units_no'] = float(request.POST['unit_val'])
                    request.session['inv_p_arr'] = inv_p_arr
                    return HttpResponse('1')
        elif request.POST['gn_val'] == '2':
            total_amt=0
            amt=0
            for i in inv_p_arr:
                if i['id'] == request.POST['product_id']:
                    i['price'] = float(request.POST['product_price'])
                    request.session['inv_p_arr'] = inv_p_arr
                amt = float(i['units_no'])*float(i['price'])
                total_amt = total_amt + amt
            request.session['total_amt'] = total_amt
            return HttpResponse('2')
        elif request.POST['gn_val'] == '3':
            total_amt=0
            amt=0
            for i in inv_p_arr:
                if i['id'] == request.POST['order_delete_id']:
                    i['status']=str('3')
                    request.session['inv_p_arr'] = inv_p_arr
                else:
                    amt = float(i['units_no'])*float(i['price'])
                    total_amt = total_amt + amt
            request.session['total_amt'] = total_amt
        if 'pending_arr' not in request.session:
            update_stock_status_obj = pos_inv_stock_order.objects.get(order_id=request.POST['given_order_id'])
            for k in inv_p_arr:
                for l in json.loads(update_stock_status_obj.order_arr):
                    if k['id'] == l['id']:
                        data = {
                            'id': str(l['id']),
                            'name': str(l['name']),
                            'units_no': float(l['units_no']),
                            'units': str(l['units']),
                            'price': float(l['price']),
                            'status': str(k['status']),
                        }
                        update_arr.append(data)
            update_stock_status_obj = pos_inv_stock_order.objects.filter(order_id=request.POST['given_order_id']).update(order_arr=json.dumps(update_arr))
        return HttpResponse('1')
    else:
        return HttpResponse('2')

def pos_inv_enter_purchase_bill_func(request):
    inv_p_arr = []
    update_arr = []
    arr = []
    update_order_arr = []
    date = datetime.strptime(str(timezone.now().date()), "%Y-%m-%d").date()
    if request.method == 'POST':
        update_stock_status = pos_inv_stock_order.objects.get(order_id=request.POST['purchase_order_no'])
        if 'inv_p_arr' in request.session:
            inv_p_arr.extend(request.session['inv_p_arr'])
        for j in json.loads(update_stock_status.order_arr):
            for k in inv_p_arr:
                if str(k['status']) != str('3'):
                    k['status'] = str('2')
                    request.session['inv_p_arr'] = inv_p_arr
        for y in json.loads(update_stock_status.order_arr):
            data = {
                'id': str(y['id']),
                'name': str(y['name']),
                'units_no': float(y['units_no']),
                'units': str(y['units']),
                'price': str(y['price']),
                'status': str('2'),
            }
            update_order_arr.append(data)
        update_stock_status_obj = pos_inv_stock_order.objects.filter(order_id=update_stock_status.order_id).update(order_arr=json.dumps(update_order_arr))
        for l in inv_p_arr:
            pos_inv_product_stock.objects.filter(stock_product_id_id=l['id']).update(stock_price=str(l['price']))
            if str(l['status']) == '3':
                units_no = 0
                price = 0
            else:
                units_no = l['units_no']
                price = l['price']
            data = {
                'id': str(l['id']),
                'name': str(l['name']),
                'units_no': float(units_no),
                'units': str(l['units']),
                'price': float(price),
                'status': str('2'),
            }
            arr.append(data)
        purchase_form = inv_purchase_details_form(request.POST)
        if purchase_form.is_valid():
            try:
                a = pos_inv_purchase_details.objects.filter(purchase_date__gt=str(date)).last()
                purchase_form.save()
                b = pos_inv_purchase_details.objects.filter(purchase_date__gt=str(date)).last()
                get_purchase_obj = pos_inv_purchase_details.objects.filter(purchase_id=b.purchase_id).update(purchase_order_arr=json.dumps(arr), purchase_amount=request.session['total_amt'], purchase_entered_by=request.session['user_id'])
                x = pos_inv_stock_order.objects.get(order_id=request.POST['order_id_update'])
                if x.recieved_arr == None:
                    order_update_obj = pos_inv_stock_order.objects.filter(order_id=request.POST['order_id_update']).update(order_action=3, recieved_arr=json.dumps(arr))
                else:
                    temp_arr = []
                    for i in arr:
                        for j in json.loads(x.recieved_arr):
                            if int(j['id']) == int(i['id']):
                                temp = float(j['units_no']) + float(i['units_no'])
                                data = {
                                    'id': str(l['id']),
                                    'name': str(l['name']),
                                    'units_no': float(temp),
                                    'units': str(l['units']),
                                    'price': str(l['price']),
                                    'status': str(l['status']),
                                }
                                temp_arr.append(data)
                    pos_inv_stock_order.objects.filter(order_id=x.order_id).update(recieved_arr=json.dumps(temp_arr))
                purchase_obj = pos_inv_purchase_details.objects.get(purchase_id=b.purchase_id)
                for k in json.loads(purchase_obj.purchase_order_arr):
                    sum_obj = 0
                    stock_obj = pos_inv_product_stock.objects.get(stock_product_id_id=k['id'])
                    sum_val = stock_obj.stock_val
                    sum_obj = int(sum_val) + int(k['units_no'])
                    pos_inv_product_stock.objects.filter(stock_product_id_id=int(k['id'])).update(stock_val=sum_obj)
                if 'inv_p_arr' in request.session:
                    del request.session['inv_p_arr']
                if 'total_amt' in request.session:
                    del request.session['total_amt']
                if 'ordered_by_arr' in request.session:
                    del request.session['ordered_by_arr']
                return HttpResponse('1')
            except:
                return HttpResponse('fail')
        else:
            return HttpResponse('3')
    else:
        return HttpResponse('fail');

def purchase_edit_func(request, id):
    arr = []
    a = pos_inv_purchase_details.objects.get(purchase_id=id)
    for i in json.loads(a.purchase_order_arr):
        data = {
            'purchase_id': a.purchase_id,
            'id': str(i['id']),
            'name': str(i['name']),
            'units_no': float(i['units_no']),
            'units': str(i['units']),
            'price': str(i['price']),
        }
        arr.append(data)
    request.session['inv_p_arr'] = arr
    context = {
        'purchase_edit': pos_inv_purchase_details.objects.filter(purchase_id=id),
        'arr': arr,
    }
    return render(request, 'invPurchaseEdit.html', context)

def order_show_edit_update_func(request, id):
    a = pos_inv_purchase_details.objects.get(purchase_id=id)
    inv_p_arr = []
    if 'inv_p_arr' not in request.session:
        for i in json.loads(a.purchase_order_arr):
            data = {
                'purchase_id': a.purchase_id,
                'id': str(i['id']),
                'name': str(i['name']),
                'units_no': float(i['units_no']),
                'units': str(i['units']),
                'price': str(i['price']),
            }
            inv_p_arr.append(data)
        request.session['inv_p_arr'] = inv_p_arr
    else:
        inv_p_arr.extend(request.session['inv_p_arr'])
    if request.POST['gn_val'] == '1':
        for i in inv_p_arr:
            if i['id'] == request.POST['product_id']:
                i['units_no'] = str(request.POST['unit_val'])
                request.session['inv_p_arr'] = inv_p_arr
                return HttpResponse(request.session['inv_p_arr'])
    if request.POST['gn_val'] == '2':
        for i in inv_p_arr:
            if i['id'] == request.POST['product_id']:
                i['price'] = str(request.POST['product_price'])
                request.session['inv_p_arr'] = inv_p_arr
                total_amt = sum(float(i['price']) for i in inv_p_arr * int(i['units_no']) for i in inv_p_arr)
                request.session['total_amt'] = total_amt
                return HttpResponse('2')
    return HttpResponse('3')

def edit_order_update_func(request, id):
    inv_p_arr = []
    if request.method == 'POST':
        if 'inv_p_arr' in request.session:
            inv_p_arr.extend(request.session['inv_p_arr'])
        a = pos_inv_purchase_details.objects.get(purchase_id=id)
        edit_purchase_form = inv_purchase_details_form(request.POST, instance=a)
        if edit_purchase_form.is_valid():
            # return HttpResponse('hi')
            try:
                edit_purchase_form.save()
                if 'total_amt' in request.session:
                    a = pos_inv_purchase_details.objects.filter(purchase_id=id).update(purchase_order_arr=json.dumps(inv_p_arr), purchase_amount=request.session['total_amt'])
                else:
                    a = pos_inv_purchase_details.objects.filter(purchase_id=id).update(purchase_order_arr=json.dumps(inv_p_arr))
                b = pos_inv_purchase_details.objects.get(purchase_id=id)
                for k in json.loads(b.purchase_order_arr):
                    sum_obj = 0
                    stock_obj = pos_inv_product_stock.objects.get(stock_product_id_id=k['id'])
                    sum_val = stock_obj.stock_val
                    sum_obj = int(sum_val) + int(k['units_no'])
                    pos_inv_product_stock.objects.filter(stock_product_id_id=k['id']).update(stock_val=k['units_no'])
                return HttpResponse('pass')
            except:
                return HttpResponse('fail')
        else:
            return HttpResponse(edit_purchase_form.errors.as_data())
    else:
        return HttpResponse(id)

def clear_session_func(request):
    if 'inv_p_arr' in request.session:
        del request.session['inv_p_arr']
    if 'total_amt' in request.session:
        del request.session['total_amt']
    if 'ordered_by_arr' in request.session:
        del request.session['ordered_by_arr']
    return HttpResponse('1')

def pos_inv_bill_payment_func(request):
    arr = []
    if request.method == 'POST':
        if request.POST['payment_type'] == '1':
            bill_payment_obj = pos_inv_bill_payment(payment_bill_number_id=request.POST['payment_id'], payment_type=request.POST['payment_type'], payment_reciever=request.POST['payment_reciever'], payment_amount=request.POST['payment_amount'], payment_note=request.POST['payment_note'], cheque_details=None, payment_bill_account=None)
        elif request.POST['payment_type'] == '2':
            data = {
                'payee_name': request.POST['payee_name'],
                'cheque_number': request.POST['cheque_number'],
                'cheque_date': request.POST['cheque_date'],
                'cheque_bank': request.POST['cheque_bank'],
            }
            arr.append(data)
            bill_payment_obj = pos_inv_bill_payment(payment_bill_number_id=request.POST['payment_id'], payment_type=request.POST['payment_type'], payment_reciever=request.POST['payment_reciever'], payment_amount=request.POST['payment_amount'], payment_note=request.POST['payment_note'], cheque_details=json.dumps(arr), payment_bill_account=None)
        elif request.POST['payment_type'] == '3':
            bill_payment_obj = pos_inv_bill_payment(payment_bill_number_id=request.POST['payment_id'], payment_type=request.POST['payment_type'], payment_reciever=None, payment_amount=request.POST['payment_amount'], payment_note=request.POST['payment_note'], cheque_details=None, payment_bill_account_id=request.POST['online_payment'])
        bill_payment_obj.save()
        pos_inv_purchase_details.objects.filter(purchase_id=request.POST['payment_id']).update(purchase_settlement=1)
        return HttpResponse('1')
    else:
        return HttpResponse('2')

def kitchen_order_show(request):
    date = datetime.strptime(str(timezone.now().date()), "%Y-%m-%d").date()
    kitchen_view_arr = []
    get_sender_2th_action_arr = []
    if 'inv_k_arr' in request.session:
        del request.session['inv_k_arr']
    if 'edit_kitchen_order' in request.session:
        del request.session['edit_kitchen_order']
    if 'chef_edit' in request.session:
        del request.session['chef_edit']
    if 'chef_sended_order' in request.session:
        del request.session['chef_sended_order']
    for i in pos_inv_kitchen_delivery.objects.filter(kitchen_order_action=1):
        for j in json.loads(i.kitchen_order_arr):
            data = {
                'kitchen_order_id': i.kitchen_order_id,
                'id': str(j['id']),
                'name': str(j['name']),
                'units': str(j['units']),
                'units_no': float(j['units_no']),
                'status': str('1'),
            }
            kitchen_view_arr.append(data)
    for i in pos_inv_kitchen_delivery.objects.filter(kitchen_order_action__in=(2,3)):
        if i.kitchen_order_ref_id != None:
            get_sender_2th_action_arr.append(i.kitchen_order_ref_id)
    if request.session['user_role'] in '1,4':
        a = pos_inv_kitchen_delivery.objects.filter(~Q(kitchen_order_id__in=get_sender_2th_action_arr) & Q(kitchen_order_action=1) & Q(kitchen_order_date__gt=date))
    elif request.session['user_role'] == '5':
        a = pos_inv_kitchen_delivery.objects.filter(Q(kitchen_order_action=1) & Q(kitchen_order_date__gt=date))
    context = {
        'pos_inv_kitchen_delivery_action_zero': pos_inv_kitchen_delivery.objects.filter(Q(kitchen_order_action=0) & Q(kitchen_order_date__gt=date)),
        'pos_inv_kitchen_delivery_action_one': a,
        'pos_inv_kitchen_delivery_action_two': pos_inv_kitchen_delivery.objects.filter(Q(kitchen_order_action=2) & Q(kitchen_order_apply=1) & Q(kitchen_order_date__gt=date)),
        'kitchen_view_arr': kitchen_view_arr,
    }
    return render(request, 'invKitchen.html', context)

def select_kitchen_order(request, id):
    if 'categorySelected' in request.session:
        cid=[]
        cid.append(request.session['categorySelected'])
        for i in range(1, 10):
            for cat in pos_inv_category.objects.filter(Q(category_status=1) & ~Q(category_id__in=cid) & Q(category_parent__in=cid)):
                if cat:
                    cid.append(cat.category_id)
        posInvPro = pos_inv_product.objects.filter(Q(product_status=1) & Q(product_category__in=set(cid)))
    else:
        posInvPro = pos_inv_product.objects.filter(product_status=1)
    context = {
        'pos_inv_category_obj_kit': pos_inv_category.objects.filter(category_status=1),
        'pos_inv_product_obj_kit': posInvPro,
        'pos_inv_stock_entry_obj_kit': pos_inv_product_stock.objects.filter(stock_entry_status=1),
        'pos_inv_department_obj': pos_inv_kitchen_department.objects.filter(department_status=1),
    }
    return render(request, 'invKitchenOrder.html', context)

def select_category_product(request):
    if request.method == 'POST':
        id = request.POST['categ_id']
        if id=='0':
            del request.session['categorySelected']
        else:
            request.session['categorySelected']=id
        return HttpResponse('1')
    else:
        return HttpResponse('0')

def select_kitchen_product(request):
    inv_k_arr = []
    check = 0
    if 'inv_k_arr' in request.session:
        inv_k_arr.extend(request.session['inv_k_arr'])
        for i in inv_k_arr:
            if i['id'] == request.POST['order_id']:
                check = 1
                return HttpResponse(check)
    if check > 0:
        return HttpResponse('1')
    else:
        for i in pos_inv_product.objects.filter(product_id=request.POST['order_id']):
            data = {
                'id': str(i.product_id),
                'name': str(i.product_name),
                'units': str(i.product_units.unit_name_short),
                'units_no': str('0'),
                'status': str('1'),
            }
            inv_k_arr.append(data)
            request.session['inv_k_arr'] = inv_k_arr
        return HttpResponse(json.dumps(data), content_type='application/json')
    return HttpResponse('1')

def kitchen_set_qty(request):
    if 'inv_k_arr' in request.session:
        inv_k_arr = []
        inv_k_arr.extend(request.session['inv_k_arr'])
        for i in inv_k_arr:
            if i['id'] == request.POST['order_update_id']:
                i['units_no'] = str(request.POST['unit_val'])
                request.session['inv_k_arr'] = inv_k_arr
                return HttpResponse(inv_k_arr)

def kitchen_delete_product(request):
    inv_k_arr = []
    if 'inv_k_arr' in request.session:
        inv_k_arr.extend(request.session['inv_k_arr'])
    for i in inv_k_arr:
        if i['id'] == request.POST['order_delete_id']:
            data = {
                'id': str(i['id']),
                'name': str(i['name']),
                'units': str(i['units']),
                'units_no': str(i['units_no']),
                'status': str(i['status']),
            }
            inv_k_arr.remove(data)
            request.session['inv_k_arr'] = inv_k_arr
    if request.POST['val'] == '1':
        request.session['inv_k_arr'] = inv_k_arr
    else:
        del_order_arr_obj = pos_inv_kitchen_delivery.objects.filter(kitchen_order_id=request.session['kitchen_order_id']).update(kitchen_order_arr=json.dumps(inv_k_arr))
    return HttpResponse(1)

def create_kitchen_products(request, role, save_order):
    # role -> (0 - SHopKeeper or Admin , 1 - Chef)
    # save_order -> (0 - Save , 1 - Update, 2 - Send)
    inv_k_arr = []
    check_stock_val_cnt = 0
    date = datetime.strptime(str(timezone.now().date()), "%Y-%m-%d").date()
    order_text_number = 0

    if 'inv_k_arr' in request.session:
        inv_k_arr.extend(request.session['inv_k_arr'])

    # Stock Value Checking

    for i in inv_k_arr:
        check_stock_value = pos_inv_product_stock.objects.get(stock_product_id_id=i['id'])
        if float(check_stock_value.stock_val) < float(i['units_no']):
            check_stock_val_cnt += 1
    if check_stock_val_cnt > 0:
        return HttpResponse('value exceed')

    # Check Role

    set_action = 0
    if role == '1' and save_order in '0, 1':
        set_action = 2
    elif role == '0' and save_order in '0, 1':
        set_action = 0
    elif role == '1' and save_order == '2':
        set_action = 3
    elif role == '0' and save_order == '2':
        set_action = 1

    # Get Reference ID
    ref_id = 0
    if 'chef_sended_order' in request.session:
        ref_id = request.session['chef_sended_order']
        ref_department_name = pos_inv_kitchen_delivery.objects.get(kitchen_order_id=request.session['chef_sended_order'])
        dep_name = int(ref_department_name.kitchen_department_id)
    else:
        ref_id = None
        dep_name = None

    # Kitcher Orders
    # return HttpResponse(request.method)
    if request.method == 'POST':
        if set_action == 0 or set_action == 1:
            chq_ex_order = pos_inv_kitchen_delivery.objects.filter(Q(kitchen_order_date__gt=str(date)) & Q(kitchen_order_action__in=(0, 1))).last()
            if chq_ex_order == None:
                last_kit_num = 0
            else:
                last_order_number_obj = pos_inv_kitchen_delivery.objects.get(Q(kitchen_order_id=chq_ex_order.kitchen_order_id))
                order_text_obj = str(last_order_number_obj.kitchen_order_number)
                last_kit_num = int(order_text_obj[5:None])
            last_kit_num += 1
            order_text_number = str('C') + str(date.strftime('%m%d')) + str(str(last_kit_num).zfill(3))
        else:
            chq_ex_order = pos_inv_kitchen_delivery.objects.filter(Q(kitchen_order_date__gt=str(date)) & Q(kitchen_order_action__in=(2,3))).last()
            if chq_ex_order == None:
                last_kit_num = 0
            else:
                last_order_number_obj = pos_inv_kitchen_delivery.objects.get(Q(kitchen_order_id=chq_ex_order.kitchen_order_id))
                order_text_obj = str(last_order_number_obj.kitchen_order_number)
                last_kit_num = int(order_text_obj[5:None])
            last_kit_num += 1
            order_text_number = str('K') + str(date.strftime('%m%d')) + str(str(last_kit_num).zfill(3))

        if save_order == '0':
            if 'chef_edit' in request.session:
                obj = pos_inv_kitchen_delivery.objects.filter(kitchen_order_id=request.session['chef_edit']).update(kitchen_order_arr=json.dumps(inv_k_arr))
            else:
                obj = pos_inv_kitchen_delivery(kitchen_order_number=str(order_text_number), kitchen_order_arr=json.dumps(inv_k_arr), kitchen_ordered_by_id=request.session['user_id'], kitchen_order_action=set_action, kitchen_order_apply=role, kitchen_department_id=dep_name, kitchen_order_ref_id=ref_id)
                obj.save()
            messages.info(request, 'Kitchen Order Successfully Saved ..!')
            return HttpResponse('save')
        elif save_order == '1':
            obj = pos_inv_kitchen_delivery.objects.filter(kitchen_order_id=request.session['edit_kitchen_order']).update(kitchen_order_arr=json.dumps(inv_k_arr))
            messages.info(request, 'Kitchen Order Successfully Updated ..!')
            return HttpResponse('update')
        elif save_order == '2':
            if 'edit_kitchen_order' in request.session:
                obj = pos_inv_kitchen_delivery.objects.get(kitchen_order_id=request.session['edit_kitchen_order'])
                obj.kitchen_order_arr = json.dumps(inv_k_arr)
                obj.kitchen_order_action = set_action
                if request.POST['kit_dpt'] == '':
                    obj.kitchen_department_id = dep_name
                else:
                    obj.kitchen_department_id = request.POST['kit_dpt']
                obj.save()
            elif 'chef_edit' in request.session:
                obj = pos_inv_kitchen_delivery.objects.get(kitchen_order_id=request.session['chef_edit'])
                obj.kitchen_order_arr = json.dumps(inv_k_arr)
                obj.kitchen_order_action = set_action
                obj.kitchen_department_id = request.POST['kit_dpt']
                obj.save()
            elif 'chef_sended_order' in request.session:
                obj = pos_inv_kitchen_delivery(kitchen_order_number=str(order_text_number), kitchen_order_arr=json.dumps(inv_k_arr), kitchen_ordered_by_id=request.session['user_id'], kitchen_order_action=set_action, kitchen_order_apply=role, kitchen_order_ref_id=ref_id, kitchen_department_id=dep_name)
                obj.save()
            else:
                obj = pos_inv_kitchen_delivery(kitchen_order_number=str(order_text_number), kitchen_order_arr=json.dumps(inv_k_arr), kitchen_ordered_by_id=request.session['user_id'], kitchen_order_action=set_action, kitchen_order_apply=role, kitchen_department_id=request.POST['kit_dpt'])
                obj.save()
            if request.session['user_role'] in '1,4':
                kitchen_obj = pos_inv_kitchen_delivery.objects.get(kitchen_order_id=obj.kitchen_order_id)
                for k in json.loads(kitchen_obj.kitchen_order_arr):
                    sum_obj = 0
                    stock_obj = pos_inv_product_stock.objects.get(stock_product_id_id=k['id'])
                    sum_val = stock_obj.stock_val
                    sum_obj = float(sum_val) - float(k['units_no'])
                    if sum_obj <= 0:
                        sum_obj = 0
                    pos_inv_product_stock.objects.filter(stock_product_id_id=k['id']).update(stock_val=sum_obj)
            messages.info(request, 'Kitchen Order Successfully Sent ..!')
            return HttpResponse('send')
    else:
        return HttpResponse('post fail')

def edit_kitchen_delivery(request, id, ref):
    inv_k_arr = []
    gn_arr = []
    request.session['edit_kitchen_order'] = id
    if id != ref:
        request.session['chef_sended_order'] = ref
    if 'inv_k_arr' in request.session:
        inv_k_arr.extend(request.session['inv_k_arr'])
    else:
        order_arr_obj = pos_inv_kitchen_delivery.objects.get(kitchen_order_id=int(id))
        for i in json.loads(order_arr_obj.kitchen_order_arr):
            data = {
                'id': str(i['id']),
                'name': str(i['name']),
                'units': str(i['units']),
                'units_no': str(i['units_no']),
                'status': str(i['status']),
            }
            inv_k_arr.append(data)
        request.session['inv_k_arr'] = inv_k_arr
    chef_sended_order_arr = []
    sender_arr_obj = pos_inv_kitchen_delivery.objects.get(kitchen_order_id=int(ref))
    for i in json.loads(sender_arr_obj.kitchen_order_arr):
        data = {
            'id': str(i['id']),
            'name': str(i['name']),
            'units': str(i['units']),
            'units_no': str(i['units_no']),
            'status': str(i['status']),
        }
        chef_sended_order_arr.append(data)
    context = {
        'pos_inv_category_obj': pos_inv_category.objects.all(),
        'pos_inv_product_obj_kit': pos_inv_product.objects.filter(product_status=1),
        'pos_inv_stock_entry_obj_kit': pos_inv_product_stock.objects.filter(stock_entry_status=1),
        'pos_inv_department_obj': pos_inv_kitchen_department.objects.filter(department_status=1),
        'chef_sended_order_arr': chef_sended_order_arr
    }
    return render(request, 'invKitchenOrder.html', context)

# edit for (chef or user_role = 5) purpose

def edit_kitchen_product(request, id):
    inv_k_arr = []
    request.session['chef_edit'] = int(id)
    if 'inv_k_arr' in request.session:
        inv_k_arr.extend(request.session['inv_k_arr'])
    else:
        order_arr_obj = pos_inv_kitchen_delivery.objects.get(kitchen_order_id=int(id))
        for i in json.loads(order_arr_obj.kitchen_order_arr):
            data = {
                'id': str(i['id']),
                'name': str(i['name']),
                'units': str(i['units']),
                'units_no': str(i['units_no']),
                'status': str(i['status']),
            }
            inv_k_arr.append(data)
        request.session['inv_k_arr'] = inv_k_arr
    context = {
        'pos_inv_category_obj': pos_inv_category.objects.all(),
        'pos_inv_product_obj_kit': pos_inv_product.objects.filter(product_status=1),
        'pos_inv_stock_entry_obj_kit': pos_inv_product_stock.objects.filter(stock_entry_status=1),
        'pos_inv_edit_stock_kitchen_order': inv_k_arr,
        'pos_inv_department_obj': pos_inv_kitchen_department.objects.filter(department_status=1),
    }
    return render(request, 'invKitchenOrder.html', context)

def chef_sended_orders(request, id):
    inv_k_arr = []
    chef_sended_order_arr = []
    request.session['chef_sended_order'] = id
    if 'inv_k_arr' in request.session:
        inv_k_arr.extend(request.session['inv_k_arr'])
    else:
        order_arr_obj = pos_inv_kitchen_delivery.objects.get(kitchen_order_id=int(id))
        for i in json.loads(order_arr_obj.kitchen_order_arr):
            data = {
                'id': str(i['id']),
                'name': str(i['name']),
                'units': str(i['units']),
                'units_no': float(i['units_no']),
                'status': str(i['status']),
            }
            inv_k_arr.append(data)
        request.session['inv_k_arr'] = inv_k_arr
    gn_obj = pos_inv_kitchen_delivery.objects.get(kitchen_order_id=id)
    for i in json.loads(gn_obj.kitchen_order_arr):
        data = {
            'id': str(i['id']),
            'name': str(i['name']),
            'units': str(i['units']),
            'units_no': str(i['units_no']),
            'status': str(i['status']),
        }
        chef_sended_order_arr.append(data)
    context = {
        'pos_inv_category_obj': pos_inv_category.objects.all(),
        'pos_inv_product_obj_kit': pos_inv_product.objects.filter(product_status=1),
        'pos_inv_stock_entry_obj_kit': pos_inv_product_stock.objects.filter(stock_entry_status=1),
        'pos_inv_edit_stock_kitchen_order': inv_k_arr,
        'chef_sended_order_arr': chef_sended_order_arr,
    }
    return render(request, 'invKitchenOrder.html', context)

def common_reports(request):
    if 'report_inventory' in request.session:
        del request.session['report_inventory']
    if 'daily_date' in request.session:
        del request.session['daily_date']
    if 'from_date' in request.session and 'to_date' in request.session:
        del request.session['from_date']
        del request.session['to_date']
    if 'select_month' in request.session and 'select_year' in request.session:
        del request.session['select_month']
        del request.session['select_year']
    return render(request, 'commonReports.html')

def order_report(request, id):
    ordered_arr = []
    recieved_arr = []
    recieved_arr_not_0 = []
    temp = []
    temp1 = []
    request.session['report_inventory'] = 'order'
    if id == '1':
        if request.method == 'POST':
            from_date = datetime.strptime(str(request.POST['from']), '%Y-%m-%d').date()
            to_date = datetime.strptime(str(request.POST['to']), '%Y-%m-%d').date() + timedelta(days=1)
            request.session['from_date'] = str(from_date)
            request.session['to_date'] = str(to_date)
            return HttpResponse('1')
        else:
            if 'from_date' in request.session and 'to_date' in request.session:
                from_date = datetime.strptime(str(request.session['from_date']), '%Y-%m-%d').date()
                to_date = datetime.strptime(str(request.session['to_date']), '%Y-%m-%d').date() + timedelta(days=1)
        if 'from_date' in request.session and 'to_date' in request.session:
            for i in pos_inv_stock_order.objects.filter(Q(order_action=3) & Q(order_date__range=(from_date, to_date))):
                for j in json.loads(i.order_arr):
                    data = {
                        'order_id': i.order_id,
                        'id': str(j['id']),
                        'name': str(j['name']),
                        'units_no': str(j['units_no']),
                        'units': str(j['units']),
                        'status': str(j['status'])
                    }
                    ordered_arr.append(data)
                for k in json.loads(i.recieved_arr):
                    st=0
                    for kk in k.keys():
                        st = k[kk]
                        break
                    data = {
                        'purchase_id': i.order_id,
                        'id': str(k['id']),
                        'name': str(k['name']),
                        'units_no': str(k['units_no']),
                        'units': str(k['units']),
                        'status': str(st),
                    }
                    recieved_arr_not_0.append(data)
                    if k['units_no'] != float(0):
                        data = {
                            'purchase_id': i.order_id,
                            'id': str(k['id']),
                            'name': str(k['name']),
                            'units_no': str(k['units_no']),
                            'units': str(k['units']),
                            'status': str(st),
                        }
                        recieved_arr.append(data)
            for i in ordered_arr:
                for j in recieved_arr_not_0:
                    if i['order_id'] == j['purchase_id']:
                        if i['id'] == j['id']:
                            if float(i['units_no']) != float(j['units_no']):
                                data1 = {
                                    'id': i['order_id'],
                                    'stat': 1,
                                }
                                temp.append(data1)
            for i in pos_inv_stock_order.objects.filter(Q(order_action=3)):
                c = 0
                for j in temp:
                    if j['id'] == i.order_id:
                        c += int(j['stat'])
                if c == 0:
                    data = {
                        'id': i.order_id,
                        'status': 'Completed',
                    }
                else:
                    data = {
                        'id': i.order_id,
                        'status': 'Pending',
                    }
                temp1.append(data)
            context = {
                'ordered_arr': ordered_arr,
                'ordered_obj': pos_inv_stock_order.objects.filter(Q(order_action=3) & Q(order_date__range=(from_date, to_date))),
                'recieved_arr': recieved_arr,
                'check_status': temp1,
                'date_show': 3,
            }
            return render(request, 'invReport.html', context)
        else:
            context = {
                'date_show': 3,
            }
            return render(request, 'invReport.html', context)
    elif id == '2':
        if request.method == 'POST':
            daily_date = datetime.strptime(str(request.POST['daily_date']), '%Y-%m-%d').date()
            given_date = daily_date + timedelta(days=1)
            request.session['daily_date'] = str(daily_date)
            return HttpResponse('1')
        else:
            if 'daily_date' in request.session:
                daily_date = datetime.strptime(str(request.session['daily_date']), '%Y-%m-%d').date()
                given_date = daily_date + timedelta(days=1)
            else:
                daily_date = datetime.strptime(str(timezone.now().date()), '%Y-%m-%d').date()
                given_date = daily_date + timedelta(days=1)
        for i in pos_inv_stock_order.objects.filter(Q(order_action=3) & Q(order_date__range=(daily_date, given_date))):
            for j in json.loads(i.order_arr):
                data = {
                    'order_id': i.order_id,
                    'id': str(j['id']),
                    'name': str(j['name']),
                    'units_no': str(j['units_no']),
                    'units': str(j['units']),
                    'status': str(j['status'])
                }
                ordered_arr.append(data)
            for k in json.loads(i.recieved_arr):
                st=0
                for kk in k.keys():
                    st = k[kk]
                    break
                data = {
                    'purchase_id': i.order_id,
                    'id': str(k['id']),
                    'name': str(k['name']),
                    'units_no': str(k['units_no']),
                    'units': str(k['units']),
                    'status': str(st),
                }
                recieved_arr_not_0.append(data)
                if k['units_no'] != float(0):
                    data = {
                        'purchase_id': i.order_id,
                        'id': str(k['id']),
                        'name': str(k['name']),
                        'units_no': str(k['units_no']),
                        'units': str(k['units']),
                        'status': str(st),
                    }
                    recieved_arr.append(data)
        for i in ordered_arr:
            for j in recieved_arr_not_0:
                if i['order_id'] == j['purchase_id']:
                    if i['id'] == j['id']:
                        if float(i['units_no']) != float(j['units_no']):
                            data1 = {
                                'id': i['order_id'],
                                'stat': 1,
                            }
                            temp.append(data1)
        for i in pos_inv_stock_order.objects.all():
            c = 0
            for j in temp:
                if j['id'] == i.order_id:
                    c += int(j['stat'])
            if c == 0:
                data = {
                    'id': i.order_id,
                    'status': 'Completed',
                }
            else:
                data = {
                    'id': i.order_id,
                    'status': 'Pending',
                }
            temp1.append(data)
        context = {
            'ordered_arr': ordered_arr,
            'ordered_obj': pos_inv_stock_order.objects.filter(Q(order_action=3) & Q(order_date__range=(daily_date, given_date))),
            'recieved_arr': recieved_arr,
            'check_status': temp1,
            'date_show': 1,
        }
        return render(request, 'invReport.html', context)
    elif id == '3':
        b = pos_inv_stock_order.objects.all()
        year = []
        for j in b:
            year.append(j.order_date.strftime("%Y"))
        distinct_years = set(year)
        if request.method == 'POST':
            Month = request.POST['select_month']
            Year = request.POST['select_year']
            get_date = str(Year+"-"+Month+"-01")
            daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
            given_month = daily_date + relativedelta(months=1)
            request.session['select_month'] = Month
            request.session['select_year'] = Year
            return HttpResponse('1')
        else:
            if 'select_year' in request.session and 'select_month' in request.session:
                get_date = str(request.session['select_year']+"-"+request.session['select_month']+"-01")
                daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
                given_month = daily_date + relativedelta(months=1)
            else:
                a = datetime.strptime(str(timezone.now().date()), '%Y-%m-%d').date()
                Year = a.strftime('%Y')
                Month = a.strftime('%m')
                get_date = str(Year+"-"+Month+"-01")
                daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
                given_month = daily_date + relativedelta(months=1)
        for i in pos_inv_stock_order.objects.filter(Q(order_action=3) & Q(order_date__range=(daily_date, given_month))):
            for j in json.loads(i.order_arr):
                data = {
                    'order_id': i.order_id,
                    'id': str(j['id']),
                    'name': str(j['name']),
                    'units_no': str(j['units_no']),
                    'units': str(j['units']),
                    'status': str(j['status'])
                }
                ordered_arr.append(data)
        for i in pos_inv_stock_order.objects.filter(order_date__range=(daily_date, given_month)):
            for j in pos_inv_purchase_details.objects.filter(purchase_order_no_id=str(i.order_id)):
                for k in json.loads(j.purchase_order_arr):
                    st=0
                    for kk in k.keys():
                        st = k[kk]
                        break
                    if k['units_no'] != float(0):
                        data = {
                            'purchase_id': i.order_id,
                            'id': str(k['id']),
                            'name': str(k['name']),
                            'units_no': str(k['units_no']),
                            'units': str(k['units']),
                            'status': str(st),
                        }
                        recieved_arr.append(data)
                    data = {
                        'purchase_id': i.order_id,
                        'id': str(k['id']),
                        'name': str(k['name']),
                        'units_no': str(k['units_no']),
                        'units': str(k['units']),
                        'status': str(st),
                    }
                    recieved_arr_not_0.append(data)
        for i in ordered_arr:
            for j in recieved_arr_not_0:
                if i['order_id'] == j['purchase_id']:
                    if i['id'] == j['id']:
                        if float(i['units_no']) != float(j['units_no']):
                            data1 = {
                                'id': i['order_id'],
                                'stat': 1,
                            }
                            temp.append(data1)
        for i in pos_inv_stock_order.objects.all():
            c = 0
            for j in temp:
                if j['id'] == i.order_id:
                    c += int(j['stat'])
            if c == 0:
                data = {
                    'id': i.order_id,
                    'status': 'Completed',
                }
            else:
                data = {
                    'id': i.order_id,
                    'status': 'Pending',
                }
            temp1.append(data)
        context = {
            'distinct_years': distinct_years,
            'ordered_arr': ordered_arr,
            'ordered_obj': pos_inv_stock_order.objects.filter(Q(order_action=3) & Q(order_date__range=(daily_date, given_month))),
            'recieved_arr': recieved_arr,
            'check_status': temp1,
            'date_show': 2,
        }
        return render(request, 'invReport.html', context)

def purchase_report(request, id):
    amt = []
    purchase_arr = []
    request.session['report_inventory'] = 'purchase'
    if id == '1':
        if request.method == 'POST':
            from_date = datetime.strptime(str(request.POST['from']), '%Y-%m-%d').date()
            to_date = datetime.strptime(str(request.POST['to']), '%Y-%m-%d').date() + timedelta(days=1)
            request.session['from_date'] = str(from_date)
            request.session['to_date'] = str(to_date)
            return HttpResponse('1')
        else:
            if 'from_date' in request.session and 'to_date' in request.session:
                from_date = datetime.strptime(str(request.session['from_date']), '%Y-%m-%d').date()
                to_date = datetime.strptime(str(request.session['to_date']), '%Y-%m-%d').date() + timedelta(days=1)
                for i in pos_inv_purchase_details.objects.filter(Q(purchase_date__range=(from_date, to_date)) & Q(purchase_statement=1)):
                    for j in json.loads(i.purchase_order_arr):
                        data = {
                            'purchase_id': i.purchase_id,
                            'id': str(j['id']),
                            'name': str(j['name']),
                            'units_no': str(j['units_no']),
                            'units': str(j['units']),
                            'price': str(j['price']),
                        }
                        purchase_arr.append(data)
                for m in pos_inv_purchase_details.objects.all():
                    a = 0
                    for n in pos_inv_bill_payment.objects.all():
                        if n.payment_bill_number_id == m.purchase_id:
                            a += int(n.payment_amount)
                    data = {
                        'amt': a,
                        'id': m.purchase_id,
                    }
                    amt.append(data)
                context = {
                    'purchase_arr': purchase_arr,
                    'paid_amt': amt,
                    'date_show': 3,
                    'payment_obj': pos_inv_bill_payment.objects.all(),
                    'purchase_obj': pos_inv_purchase_details.objects.filter(Q(purchase_date__range=(from_date, to_date)) & Q(purchase_statement=1)),
                }
                return render(request, 'invReport.html', context)
            else:
                context = {
                    'date_show': 3,
                }
                return render(request, 'invReport.html', context)
    elif id == '2':
        if request.method == 'POST':
            daily_date = datetime.strptime(str(request.POST['daily_date']), '%Y-%m-%d').date()
            given_date = daily_date + timedelta(days=1)
            request.session['daily_date'] = str(daily_date)
            return HttpResponse('1')
        else:
            if 'daily_date' in request.session:
                daily_date = datetime.strptime(str(request.session['daily_date']), '%Y-%m-%d').date()
                given_date = daily_date + timedelta(days=1)
            else:
                daily_date = datetime.strptime(str(timezone.now().date()), '%Y-%m-%d').date()
                given_date = daily_date + timedelta(days=1)
        for i in pos_inv_purchase_details.objects.filter(Q(purchase_date__range=(daily_date, given_date)) & Q(purchase_statement=1)):
            for j in json.loads(i.purchase_order_arr):
                data = {
                    'purchase_id': i.purchase_id,
                    'id': str(j['id']),
                    'name': str(j['name']),
                    'units_no': str(j['units_no']),
                    'units': str(j['units']),
                    'price': str(j['price']),
                }
                purchase_arr.append(data)
        for m in pos_inv_purchase_details.objects.all():
            a = 0
            for n in pos_inv_bill_payment.objects.all():
                if n.payment_bill_number_id == m.purchase_id:
                    a += int(n.payment_amount)
            data = {
                'amt': a,
                'id': m.purchase_id,
            }
            amt.append(data)
        context = {
            'purchase_arr': purchase_arr,
            'purchase_obj': pos_inv_purchase_details.objects.filter(Q(purchase_date__range=(daily_date, given_date)) & Q(purchase_statement=1)),
            'date_show': 1,
            'paid_amt': amt,
            'payment_obj': pos_inv_bill_payment.objects.all(),
        }
        return render(request, 'invReport.html', context)
    elif id == '3':
        b = pos_inv_purchase_details.objects.all()
        year = []
        for j in b:
            year.append(j.purchase_date.strftime("%Y"))
        distinct_years = set(year)
        if request.method == 'POST':
            Month = request.POST['select_month']
            Year = request.POST['select_year']
            get_date = str(Year+"-"+Month+"-01")
            daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
            given_month = daily_date + relativedelta(months=1)
            request.session['select_month'] = Month
            request.session['select_year'] = Year
            return HttpResponse('1')
        else:
            if 'select_year' in request.session and 'select_month' in request.session:
                get_date = str(request.session['select_year']+"-"+request.session['select_month']+"-01")
                daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
                given_month = daily_date + relativedelta(months=1)
            else:
                a = datetime.strptime(str(timezone.now().date()), '%Y-%m-%d').date()
                Year = a.strftime('%Y')
                Month = a.strftime('%m')
                get_date = str(Year+"-"+Month+"-01")
                daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
                given_month = daily_date + relativedelta(months=1)
        for i in pos_inv_purchase_details.objects.filter(Q(purchase_date__range=(daily_date, given_month)) & Q(purchase_statement=1)):
            for j in json.loads(i.purchase_order_arr):
                data = {
                    'purchase_id': i.purchase_id,
                    'id': str(j['id']),
                    'name': str(j['name']),
                    'units_no': str(j['units_no']),
                    'units': str(j['units']),
                    'price': str(j['price']),
                }
                purchase_arr.append(data)
        for m in pos_inv_purchase_details.objects.all():
            a = 0
            for n in pos_inv_bill_payment.objects.all():
                if n.payment_bill_number_id == m.purchase_id:
                    a += int(n.payment_amount)
            data = {
                'amt': a,
                'id': m.purchase_id,
            }
            amt.append(data)
        context = {
            'distinct_years': distinct_years,
            'purchase_arr': purchase_arr,
            'purchase_obj': pos_inv_purchase_details.objects.filter(Q(purchase_date__range=(daily_date, given_month)) & Q(purchase_statement=1)),
            'payment_obj': pos_inv_bill_payment.objects.all(),
            'paid_amt': amt,
            'date_show': 2,
        }
        return render(request, 'invReport.html', context)

def kitchen_report(request, id):
    kitchen_arr = []
    request.session['report_inventory'] = 'kitchen'
    if id == '1':
        if request.method == 'POST':
            from_date = datetime.strptime(str(request.POST['from']), '%Y-%m-%d').date()
            to_date = datetime.strptime(str(request.POST['to']), '%Y-%m-%d').date() + timedelta(days=1)
            request.session['from_date'] = str(from_date)
            request.session['to_date'] = str(to_date)
            return HttpResponse('1')
        else:
            if 'from_date' in request.session and 'to_date' in request.session:
                from_date = datetime.strptime(str(request.session['from_date']), '%Y-%m-%d').date()
                to_date = datetime.strptime(str(request.session['to_date']), '%Y-%m-%d').date() + timedelta(days=1)
                for i in pos_inv_kitchen_delivery.objects.filter(kitchen_order_date__range=(from_date, to_date)):
                    for j in json.loads(i.kitchen_order_arr):
                        data = {
                            'kitchen_order_id': i.kitchen_order_id,
                            'id': str(j['id']),
                            'name': str(j['name']),
                            'units_no': str(j['units_no']),
                            'units': str(j['units']),
                        }
                        kitchen_arr.append(data)
                context = {
                    'kitchen_arr': kitchen_arr,
                    'kitchen_obj': pos_inv_kitchen_delivery.objects.filter(kitchen_order_date__range=(from_date, to_date)),
                    'date_show': 3,
                }
                return render(request, 'invReport.html', context)
            else:
                context = {
                    'date_show': 3,
                }
                return render(request, 'invReport.html', context)
    elif id == '2':
        if request.method == 'POST':
            daily_date = datetime.strptime(str(request.POST['daily_date']), '%Y-%m-%d').date()
            given_date = daily_date + timedelta(days=1)
            request.session['daily_date'] = str(daily_date)
            return HttpResponse('1')
        else:
            if 'daily_date' in request.session:
                daily_date = datetime.strptime(str(request.session['daily_date']), '%Y-%m-%d').date()
                given_date = daily_date + timedelta(days=1)
            else:
                daily_date = datetime.strptime(str(timezone.now().date()), '%Y-%m-%d').date()
                given_date = daily_date + timedelta(days=1)
        for i in pos_inv_kitchen_delivery.objects.filter(kitchen_order_date__range=(daily_date, given_date)):
            for j in json.loads(i.kitchen_order_arr):
                data = {
                    'kitchen_order_id': i.kitchen_order_id,
                    'id': str(j['id']),
                    'name': str(j['name']),
                    'units_no': str(j['units_no']),
                    'units': str(j['units']),
                }
                kitchen_arr.append(data)
        context = {
            'kitchen_arr': kitchen_arr,
            'kitchen_obj': pos_inv_kitchen_delivery.objects.filter(Q(kitchen_order_date__range=(daily_date, given_date)) & Q(kitchen_order_action=3)),
            'date_show': 1,
        }
        return render(request, 'invReport.html', context)
    elif id == '3':
        b = pos_inv_kitchen_delivery.objects.all()
        year = []
        for j in b:
            year.append(j.kitchen_order_date.strftime("%Y"))
        distinct_years = set(year)
        if request.method == 'POST':
            Month = request.POST['select_month']
            Year = request.POST['select_year']
            get_date = str(Year+"-"+Month+"-01")
            daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
            given_month = daily_date + relativedelta(months=1)
            request.session['select_month'] = Month
            request.session['select_year'] = Year
            return HttpResponse('1')
        else:
            if 'select_year' in request.session and 'select_month' in request.session:
                get_date = str(request.session['select_year']+"-"+request.session['select_month']+"-01")
                daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
                given_month = daily_date + relativedelta(months=1)
            else:
                a = datetime.strptime(str(timezone.now().date()), '%Y-%m-%d').date()
                Year = a.strftime('%Y')
                Month = a.strftime('%m')
                get_date = str(Year+"-"+Month+"-01")
                daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
                given_month = daily_date + relativedelta(months=1)
        for i in pos_inv_kitchen_delivery.objects.filter(kitchen_order_date__range=(daily_date, given_month)):
            for j in json.loads(i.kitchen_order_arr):
                data = {
                    'kitchen_order_id': i.kitchen_order_id,
                    'id': str(j['id']),
                    'name': str(j['name']),
                    'units_no': str(j['units_no']),
                    'units': str(j['units']),
                }
                kitchen_arr.append(data)
        context = {
            'distinct_years': distinct_years,
            'kitchen_arr': kitchen_arr,
            'kitchen_obj': pos_inv_kitchen_delivery.objects.filter(kitchen_order_date__range=(daily_date, given_month)),
            'date_show': 2,
        }
        return render(request, 'invReport.html', context)

def transaction_report(request, id):
    payment_arr = []
    arr = []
    request.session['report_inventory'] = 'transaction'
    if id == '1':
        if request.method == 'POST':
            from_date = datetime.strptime(str(request.POST['from']), '%Y-%m-%d').date()
            to_date = datetime.strptime(str(request.POST['to']), '%Y-%m-%d').date() + timedelta(days=1)
            request.session['from_date'] = str(from_date)
            request.session['to_date'] = str(to_date)
            return HttpResponse('1')
        else:
            if 'from_date' in request.session and 'to_date' in request.session:
                from_date = datetime.strptime(str(request.session['from_date']), '%Y-%m-%d').date()
                to_date = datetime.strptime(str(request.session['to_date']), '%Y-%m-%d').date() + timedelta(days=1)
                for i in pos_inv_bill_payment.objects.filter(payment_date__range=(from_date, to_date)):
                    for j in pos_inv_supplier_account_details.objects.all():
                        if j.supplier_account_id == i.payment_bill_account_id:
                            data = {
                                'id': i.bill_payment_id,
                                'bank_name': j.bank_name,
                                'holder_name': j.account_holder_name,
                                'account_number': j.account_number,
                                'supplier_ref_id': j.supplier_ref_id.store_name,
                            }
                            payment_arr.append(data)
                context = {
                    'payment_arr': payment_arr,
                    'payment_obj': pos_inv_bill_payment.objects.filter(payment_date__range=(from_date, to_date)),
                    'date_show': 3,
                }
                return render(request, 'invReport.html', context)
            else:
                context = {
                    'date_show': 3,
                }
                return render(request, 'invReport.html', context)
    elif id == '2':
        if request.method == 'POST':
            daily_date = datetime.strptime(str(request.POST['daily_date']), '%Y-%m-%d').date()
            given_date = daily_date + timedelta(days=1)
            request.session['daily_date'] = str(daily_date)
            return HttpResponse('1')
        else:
            if 'daily_date' in request.session:
                daily_date = datetime.strptime(str(request.session['daily_date']), '%Y-%m-%d').date()
                given_date = daily_date + timedelta(days=1)
            else:
                daily_date = datetime.strptime(str(timezone.now().date()), '%Y-%m-%d').date()
                given_date = daily_date + timedelta(days=1)
        for i in pos_inv_bill_payment.objects.filter(payment_date__range=(daily_date, given_date)):
            for j in pos_inv_supplier_account_details.objects.all():
                if j.supplier_account_id == i.payment_bill_account_id:
                    data = {
                        'id': i.bill_payment_id,
                        'bank_name': j.bank_name,
                        'holder_name': j.account_holder_name,
                        'account_number': j.account_number,
                        'supplier_ref_id': j.supplier_ref_id.store_name,
                    }
                    payment_arr.append(data)
        context = {
            'payment_arr': payment_arr,
            'payment_obj': pos_inv_bill_payment.objects.filter(payment_date__range=(daily_date, given_date)),
            'date_show': 1,
        }
        return render(request, 'invReport.html', context)
    elif id == '3':
        b = pos_inv_bill_payment.objects.all()
        year = []
        for j in b:
            year.append(j.payment_date.strftime("%Y"))
        distinct_years = set(year)
        if request.method == 'POST':
            Month = request.POST['select_month']
            Year = request.POST['select_year']
            get_date = str(Year+"-"+Month+"-01")
            daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
            given_month = daily_date + relativedelta(months=1)
            request.session['select_month'] = Month
            request.session['select_year'] = Year
            return HttpResponse('1')
        else:
            if 'select_year' in request.session and 'select_month' in request.session:
                get_date = str(request.session['select_year']+"-"+request.session['select_month']+"-01")
                daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
                given_month = daily_date + relativedelta(months=1)
            else:
                a = datetime.strptime(str(timezone.now().date()), '%Y-%m-%d').date()
                Year = a.strftime('%Y')
                Month = a.strftime('%m')
                get_date = str(Year+"-"+Month+"-01")
                daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
                given_month = daily_date + relativedelta(months=1)
        for i in pos_inv_bill_payment.objects.filter(payment_date__range=(daily_date, given_month)):
            for j in pos_inv_supplier_account_details.objects.all():
                if j.supplier_account_id == i.payment_bill_account_id:
                    data = {
                        'id': i.bill_payment_id,
                        'bank_name': j.bank_name,
                        'holder_name': j.account_holder_name,
                        'account_number': j.account_number,
                        'supplier_ref_id': j.supplier_ref_id.store_name,
                    }
                    payment_arr.append(data)
        context = {
            'date_show': 2,
            'distinct_years': distinct_years,
            'payment_arr': payment_arr,
            'payment_obj': pos_inv_bill_payment.objects.filter(payment_date__range=(daily_date, given_month)),
        }
        return render(request, 'invReport.html', context)

def return_purchase_reports(request, id):
    return_purchase_arr = []
    amt = []
    request.session['report_inventory'] = 'return_purchase'
    if id == '1':
        if request.method == 'POST':
            from_date = datetime.strptime(str(request.POST['from']), '%Y-%m-%d').date()
            to_date = datetime.strptime(str(request.POST['to']), '%Y-%m-%d').date() + timedelta(days=1)
            request.session['from_date'] = str(from_date)
            request.session['to_date'] = str(to_date)
            return HttpResponse('1')
        else:
            if 'from_date' in request.session and 'to_date' in request.session:
                from_date = datetime.strptime(str(request.session['from_date']), '%Y-%m-%d').date()
                to_date = datetime.strptime(str(request.session['to_date']), '%Y-%m-%d').date() + timedelta(days=1)
                for i in pos_inv_purchase_details.objects.filter(Q(purchase_date__range=(from_date, to_date)) & Q(purchase_statement=0)):
                    for j in json.loads(i.purchase_order_arr):
                        data = {
                            'purchase_id': i.purchase_id,
                            'id': str(j['id']),
                            'name': str(j['name']),
                            'units_no': str(j['units_no']),
                            'units': str(j['units']),
                            'price': str(j['price']),
                        }
                        return_purchase_arr.append(data)
                context = {
                    'return_purchase_arr': return_purchase_arr,
                    'purchase_obj': pos_inv_purchase_details.objects.filter(Q(purchase_date__range=(from_date, to_date)) & Q(purchase_statement=0)),
                    'date_show': 3,
                }
                return render(request, 'invReport.html', context)
            else:
                context = {
                    'date_show': 3,
                }
                return render(request, 'invReport.html', context)
    elif id == '2':
        if request.method == 'POST':
            daily_date = datetime.strptime(str(request.POST['daily_date']), '%Y-%m-%d').date()
            given_date = daily_date + timedelta(days=1)
            request.session['daily_date'] = str(daily_date)
            return HttpResponse('1')
        else:
            if 'daily_date' in request.session:
                daily_date = datetime.strptime(str(request.session['daily_date']), '%Y-%m-%d').date()
                given_date = daily_date + timedelta(days=1)
            else:
                daily_date = datetime.strptime(str(timezone.now().date()), '%Y-%m-%d').date()
                given_date = daily_date + timedelta(days=1)
        for i in pos_inv_purchase_details.objects.filter(Q(purchase_date__range=(daily_date, given_date)) & Q(purchase_statement=0)):
            for j in json.loads(i.purchase_order_arr):
                data = {
                    'purchase_id': i.purchase_id,
                    'id': str(j['id']),
                    'name': str(j['name']),
                    'units_no': str(j['units_no']),
                    'units': str(j['units']),
                    'price': str(j['price']),
                }
                return_purchase_arr.append(data)
        context = {
            'return_purchase_arr': return_purchase_arr,
            'purchase_obj': pos_inv_purchase_details.objects.filter(Q(purchase_date__range=(daily_date, given_date)) & Q(purchase_statement=0)),
            'date_show': 1,
        }
        return render(request, 'invReport.html', context)
    elif id == '3':
        b = pos_inv_purchase_details.objects.filter(purchase_statement=0)
        year = []
        for j in b:
            year.append(j.purchase_date.strftime("%Y"))
        distinct_years = set(year)
        if request.method == 'POST':
            Month = request.POST['select_month']
            Year = request.POST['select_year']
            get_date = str(Year+"-"+Month+"-01")
            daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
            given_month = daily_date + relativedelta(months=1)
            request.session['select_month'] = Month
            request.session['select_year'] = Year
            return HttpResponse('1')
        else:
            if 'select_year' in request.session and 'select_month' in request.session:
                get_date = str(request.session['select_year']+"-"+request.session['select_month']+"-01")
                daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
                given_month = daily_date + relativedelta(months=1)
            else:
                a = datetime.strptime(str(timezone.now().date()), '%Y-%m-%d').date()
                Year = a.strftime('%Y')
                Month = a.strftime('%m')
                get_date = str(Year+"-"+Month+"-01")
                daily_date = datetime.strptime(get_date, '%Y-%m-%d').date()
                given_month = daily_date + relativedelta(months=1)
        for i in pos_inv_purchase_details.objects.filter(Q(purchase_date__range=(daily_date, given_month)) & Q(purchase_statement=0)):
            for j in json.loads(i.purchase_order_arr):
                data = {
                    'purchase_id': i.purchase_id,
                    'id': str(j['id']),
                    'name': str(j['name']),
                    'units_no': str(j['units_no']),
                    'units': str(j['units']),
                    'price': str(j['price']),
                }
                return_purchase_arr.append(data)
        context = {
            'date_show': 2,
            'distinct_years': distinct_years,
            'return_purchase_arr': return_purchase_arr,
            'purchase_obj': pos_inv_purchase_details.objects.filter(Q(purchase_date__range=(daily_date, given_month)) & Q(purchase_statement=0)),
        }
        return render(request, 'invReport.html', context)

def clear_report_order(request):
    if request.method == 'POST':
        if 'given_date' in request.session:
            del request.session['given_date']
        if 'report_id' in request.session:
            del request.session['report_id']
        return HttpResponse('1')
    else:
        return redirect('/index')


def pos_inv_units_func(request, id):
    if request.method == 'POST':
        if id == '1':
            add_units_form = pos_inv_units_form(request.POST)
            if add_units_form.is_valid():
                try:
                    add_units_form.save()
                    return HttpResponse('1')
                except:
                    return HttpResponse('2')
            else:
                return HttpResponse('3')
        if id == '2':
            update_product_unit = pos_inv_units.objects.filter(unit_id=request.POST['unit_id']).update(unit_name=request.POST['unit_name'], unit_name_short=request.POST['unit_name_short'])
            return HttpResponse('1')
        if id == '3':
            delete_unit_obj = pos_inv_units.objects.filter(unit_id=request.POST['del_unit']).update(unit_status=0)
            return HttpResponse('1')
    else:
        return HttpResponse('2')

def pos_inv_stock_show(request):
    arr = []
    for i in pos_inv_product_stock.objects.all():
        temp1 = pos_inv_product.objects.get(product_id=i.stock_product_id.product_id)
        temp2 = pos_inv_units.objects.get(unit_id=temp1.product_units_id)
        temp = temp2.unit_name_short
        data = {
            'name': i.stock_product_id.product_name,
            'stock_val': i.stock_val,
            'stock_unit': temp,
            'stock_price': i.stock_price,
        }
        arr.append(data)
    context = {
        'pos_inv_product_stock_obj': arr,
    }
    return render(request, 'stockShow.html', context)

def pos_inv_department(request, id):
    if request.method == 'POST':
        if id == '0':
            context = {
                'pos_inv_kitchen_department_obj': pos_inv_kitchen_department.objects.filter(department_status=1),
            }
            return render(request, 'department.html', context)
        elif id == '1':
            add_kitchen_department_form = pos_inv_kitchen_department_form(request.POST)
            if add_kitchen_department_form.is_valid():
                try:
                    add_kitchen_department_form.save()
                    messages.info(request, "Department Successfully Created ..!")
                    return HttpResponse('1')
                except:
                    pass
                    return HttpResponse('2')
            else:
                return HttpResponse('3')
        elif id == '2':
            edit_kitchen_department_form = pos_inv_kitchen_department_form(request.POST, instance=pos_inv_kitchen_department.objects.get(department_id=request.POST['department_id']))
            if edit_kitchen_department_form.is_valid():
                try:
                    edit_kitchen_department_form.save()
                    messages.info(request, "Department Successfully Updated ..!")
                    return HttpResponse('1')
                except:
                    pass
                    return HttpResponse('2')
            else:
                return HttpResponse('3')
        elif id == '3':
            del_department = pos_inv_kitchen_department.objects.filter(department_id=request.POST['del_department']).update(department_status=0)
            messages.info(request, "Department Successfully Deleted ..!")
            return HttpResponse('1')
    else:
        context = {
            'pos_inv_kitchen_department_obj': pos_inv_kitchen_department.objects.filter(department_status=1),
        }
        return render(request, 'department.html', context)

def check_stock(request):
    return HttpResponse('4')

def supplier_accounts_func(request, id):
    sup_name = pos_inv_supplier.objects.get(supplier_id=id)
    context = {
        'supplier_obj': pos_inv_supplier.objects.filter(supplier_id=id),
        'supplier_acc_obj': pos_inv_supplier_account_details.objects.filter(Q(supplier_ref_id_id=id) & Q(account_status=1)),
    }
    return render(request, 'supplierAccount.html', context)

def supplier_add_accounts(request, id):
    if request.method == 'POST':
        if id == '1':
            if request.method == "POST":
                inv_sup_acc_form = inv_supplier_acc_form(request.POST, request.FILES)
                if inv_sup_acc_form.is_valid():
                    try:
                        inv_sup_acc_form.save()
                        # messages.info(request, "Account Created Successfully ..!")
                        return HttpResponse('1')
                    except:
                        pass
                        return HttpResponse('2')
                else:
                    return HttpResponse('3')
            else:
                return HttpResponse('addfail')
            return render(request, 'invProduct.html', context)
        elif id == '2':
            if request.method == 'POST':
                edit_inv_sup_acc_form = inv_supplier_acc_form(request.POST, instance=pos_inv_supplier_account_details.objects.get(supplier_account_id=request.POST['supplier_account_id']))
                if edit_inv_sup_acc_form.is_valid():
                    try:
                        edit_inv_sup_acc_form.save()
                        # messages.info(request, "Account Updated Successfully ..!")
                        return HttpResponse('1')
                    except:
                        pass
                        return HttpResponse('2')
                else:
                    return HttpResponse('3')
            else:
                return HttpResponse('editfail')
        elif id == '3':
            if request.method == 'POST':
                delete_supplier_acc_obj = pos_inv_supplier_account_details.objects.filter(supplier_account_id=request.POST['del_sup_acc']).update(account_status=0)
                # messages.info(request, "Supplier Deleted Successfully ..!")
                return HttpResponse('1')
            else:
                return HttpResponse('deletefail')
    else:
        return HttpResponse('fail')

def inv_settings(request):
    data = []
    if 'user_id' in request.session and request.session['user_role'] == '1':
        if request.method == 'POST':
            pos_inv_settings_form_data = pos_inv_settings_form(request.POST, request.FILES)
            if pos_inv_settings_form_data.is_valid():
                pos_inv_settings_form_data.save()
                get_mail_last_obj = pos_inv_settings.objects.all().last()
                temp = {
                    'mail_no': 1,
                    'mail_name': str(pos_inv_settings_form_data.cleaned_data['to_report_mail']),
                    'mail_type': 0,
                }
                data.append(temp)
                pos_inv_settings.objects.filter(id=get_mail_last_obj.id).update(to_report_mail=json.dumps(data))
                return HttpResponse('1')
            else:
                return HttpResponse('form fail')
        else:
            setting_details = pos_inv_settings.objects.filter(id=1)
            if setting_details:
                a = pos_inv_settings.objects.get(id=1)
                data=[]
                for n in json.loads(a.to_report_mail):
                    temp={
                        'mail_no': n['mail_no'],
                        'mail_name': n['mail_name'],
                    }
                    data.append(temp)
                return render(request, 'invSettings.html', {'setting_details': setting_details, 'reportMail':data})
            else:
                return render(request, 'invSettings.html', {'setting_details': setting_details})
    else:
        return redirect('/index')

def add_mail_func(request):
    if request.method == "POST":
        new_mail = request.POST['add_new_mail']
        mail_obj = pos_inv_settings.objects.get(id=1)
        if mail_obj.to_report_mail:
            chq = 0
            data=json.loads(mail_obj.to_report_mail)
            for ar in data:
                if new_mail.lower()==ar['mail_name'].lower():
                    chq+=1
            if chq == 0:
                ml=len(data)+1
                temp={
                    'mail_no': ml,
                    'mail_name': new_mail,
                }
                data.append(temp)
            else:
                return HttpResponse('3')
            reportMail=json.dumps(data)
            mail_obj.to_report_mail = reportMail
            mail_obj.save()
        else:
            data=[]
            temp={
                'mail_no': 1,
                'mail_name': new_mail,
            }
            data.append(temp)
            reportMail=json.dumps(data)
            mail_obj.to_report_mail = reportMail
            mail_obj.save()
        return HttpResponse('1')
    else:
        return HttpResponse('2')

def edit_settings(request):
    if request.method == 'POST':
        res_id   =  request.POST['res_id']
        res_name =  request.POST['res_name']
        res_addr =  request.POST['res_addr']
        res_pinc =  request.POST['res_pinc']
        res_land =  request.POST['land_line']
        res_mail =  request.POST['report_mail']
        res_visible_days =  request.POST['visible_days']
        reportMail=json.loads(res_mail)
        data=[]
        n = 0
        for mail in reportMail:
            n += 1
            temp={
                'mail_no': n,
                'mail_name': mail,
            }
            data.append(temp)
        reportMail=json.dumps(data)
        pos_edit_setting = pos_inv_settings.objects.filter(id=res_id).update(settings_name=res_name, settings_address=res_addr, settings_pincode=res_pinc, landline_num=res_land, to_report_mail=reportMail, pending_order_visibility=res_visible_days)
        request.session['hotel_name'] = str(res_name)
        return HttpResponse('1')
    else:
        return HttpResponse('2')