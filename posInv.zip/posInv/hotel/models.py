from __future__ import unicode_literals
from django.db import models
import datetime
import os
from django.utils import formats, timezone
from django.http import HttpResponse

		# /---- create employee Model ----/

def employe_upload(instance, filename):
    ext = filename.split('.')[-1]
    filename = "%s.%s" % (instance.emp_name, ext)
    return os.path.join('images/empImg/', filename)

def category_upload(instance, filename):
    ext = filename.split('.')[-1]
    filename = "%s.%s" % (instance.category_name, ext)
    return os.path.join('images/catImg/', filename)

def product_upload(instance, filename):
    ext = filename.split('.')[-1]
    filename = "%s.%s" % (instance.product_name, ext)
    return os.path.join('images/proImg/', filename)

def supplier_upload(instance, filename):
    ext = filename.split('.')[-1]
    filename = "%s.%s" % (instance.store_name, ext)
    return os.path.join('images/supplierImg/', filename)

class pos_employee(models.Model):
	emp_name = models.CharField(max_length = 50)
	emp_img = models.ImageField(upload_to=employe_upload, blank=True, null=True, default='images/avatar.png')
	emp_address = models.CharField(max_length = 250)
	emp_age = models.CharField(max_length = 2)
	emp_gender = models.CharField(max_length = 10)
	emp_number = models.CharField(max_length = 10)
	emp_mail = models.CharField(max_length = 25, null = True)
	emp_password = models.CharField(max_length = 8)
	ROLE = (
	    ('1', 'admin'),
	    ('2', 'captain'),
	    ('3', 'billing'),
	    ('4', 'storeKeeper'),
	    ('5', 'chef'),
	)
	emp_role = models.CharField(max_length = 10, choices=ROLE)
	ACTIVE_STATUS = (
		('0', 'inactive'),
		('1', 'active'),
	)
	active_status = models.CharField(max_length=10, choices=ACTIVE_STATUS, default=1)
	def __unicode__(self):
		return self.emp_name
	class Meta:
		db_table = "pos_users_details"

class pos_inv_category(models.Model):
	category_id = models.AutoField(primary_key=True)
	category_name = models.CharField(max_length=100)
	category_image = models.ImageField(upload_to=category_upload, blank=True, null=True, default='images/food-default.png')
	CAT_ACTIVE_STATUS = (
		('0', 'inactive'),
		('1', 'active'),
	)
	category_status = models.CharField(max_length=10, choices=CAT_ACTIVE_STATUS, default=1)
	CAT_TYPE = (
		('0', 'parent'),
		('1', 'sub'),
	)
	category_type = models.CharField(max_length=50, choices=CAT_TYPE, default=0)
	category_parent = models.IntegerField(blank=True, null=True)
	def __unicode__(self):
		return self.category_name
	class Meta:
		db_table = "pos_inv_category_table"

class pos_inv_units(models.Model):
	unit_id = models.AutoField(primary_key=True)
	unit_name = models.CharField(max_length=50)
	unit_name_short = models.CharField(max_length=50)
	UNIT_ACTIVE_STATUS = (
	        ('0', 'inactive'),
	        ('1', 'active'),
	    )
	unit_status = models.CharField(max_length=10, choices=UNIT_ACTIVE_STATUS, default=1)
	def __unicode__(self):
		return self.unit_name
	class Meta:
		db_table = "pos_inv_units_table"

class pos_inv_product(models.Model):
	product_id = models.AutoField(primary_key=True)
	product_name = models.CharField(max_length=100)
	product_image = models.ImageField(upload_to=product_upload, blank=True, null=True, default='images/food-default.png')
	product_category = models.ForeignKey(pos_inv_category, blank=True, null=True)
	product_units = models.ForeignKey(pos_inv_units, blank=True, null=True)
	PRODUCT_ACTIVE_STATUS = (
		('0', 'inactive'),
		('1', 'active'),
	)
	product_status = models.CharField(max_length=10, choices=PRODUCT_ACTIVE_STATUS, default=1)
	def __unicode__(self):
		return self.product_name
	class Meta:
		db_table = "pos_inv_product_table"	

class pos_inv_product_stock(models.Model):
    stock_id = models.AutoField(primary_key=True)
    stock_product_id = models.ForeignKey(pos_inv_product)
    stock_val = models.CharField(max_length=100, default=0 )
    stock_min_val = models.CharField(max_length=100, default=0)
    stock_price = models.CharField(max_length=100, default=0 )
    STOCK_ENTRY_STATUS = (
        ('0', 'inactive'),
        ('1', 'active'),
    )
    stock_entry_status = models.CharField(max_length=100, choices=STOCK_ENTRY_STATUS)
    def __unicode__(self):
        return str(self.stock_id)
    class Meta:
        db_table = "pos_inv_product_stock_table"

class pos_inv_supplier(models.Model):
	supplier_id = models.AutoField(primary_key=True)
	supplier_image = models.ImageField(upload_to=supplier_upload, blank=True, null=True, default='images/avatar.png')
	store_name = models.CharField(max_length=100) # Store Name
	store_owner_name = models.CharField(max_length=100) # Store Owner Name
	supplier_ph_number = models.CharField(max_length=10)
	supplier_ref_ID_number = models.CharField(max_length=15) # Ref ID Number
	supplier_mail = models.CharField(max_length=100)
	supplier_address = models.TextField()
	PAYMENT_BASIS = (
		('0', 'daily'),
		('1', 'weekly'),
		('2', 'monthly'),
	)
	payment_basis = models.CharField(max_length=100, choices=PAYMENT_BASIS)
	SUPPLIER_ACTIVE_STATUS = (
		('0', 'inactive'),
		('1', 'active'),
	)
	supplier_status = models.CharField(max_length=10, choices=SUPPLIER_ACTIVE_STATUS, default=1)
	def __unicode__(self):
		return str(self.supplier_id)
	class Meta:
		db_table = "pos_inv_supplier_table"

class pos_inv_stock_order(models.Model):
	order_id = models.AutoField(primary_key=True)
	order_number = models.CharField(max_length=100)
	order_date = models.DateTimeField(auto_now_add=True)
	order_arr = models.TextField()
	recieved_arr = models.TextField(blank=True, null=True)
	order_supplier = models.ForeignKey(pos_inv_supplier, blank=True, null=True)
	ordered_by = models.ForeignKey(pos_employee,  blank=True, null=True)
	ORDER_OPTIONS = (
		('0', 'update'),
		('1', 'confirm'),
		('2', 'send'),
		('3', 'sent'),
	)
	order_action = models.CharField(max_length=100, choices=ORDER_OPTIONS)
	def __unicode__(self):
		return str(self.order_id)
	class Meta:
		db_table = "pos_inv_order_table"

class pos_inv_purchase_details(models.Model):
	purchase_id = models.AutoField(primary_key=True)
	purchase_bill_number = models.CharField(max_length=100, blank=True, null=True)
	purchase_date = models.DateTimeField(auto_now_add=True)
	purchase_bill_date = models.DateTimeField(blank=True, null=True)
	purchase_order_arr = models.TextField(blank=True, null=True)
	purchase_order_no = models.ForeignKey(pos_inv_stock_order, blank=True, null=True)
	purchase_order_supplier = models.ForeignKey(pos_inv_supplier, blank=True, null=True)
	purchase_SGST = models.CharField(max_length=50)
	purchase_CGST = models.CharField(max_length=50)
	purchase_discount = models.CharField(max_length=50, blank=True, null=True)
	purchase_amount = models.CharField(max_length=50)
	purchase_entered_by = models.ForeignKey(pos_employee, blank=True, null=True)
	PURCHASE_SETTLEMENT = (
		('0', 'unpaid'),
		('1', 'half'),
		('2', 'paid'),
	)
	purchase_settlement = models.CharField(max_length=100, choices=PURCHASE_SETTLEMENT, default=0, blank=True, null=True)
	PURCHASE_STATEMENT = (
		('0', 'return'),
		('1', 'purchase'),
	)
	purchase_statement = models.CharField(max_length=100, choices=PURCHASE_STATEMENT, default=1, blank=True, null=True)
	def __unicode__(self):
		return str(self.purchase_id)
	class Meta:
		db_table = "pos_inv_purchase_table"

class pos_inv_supplier_account_details(models.Model):
    supplier_account_id = models.AutoField(primary_key=True)
    bank_name = models.CharField(max_length=50)
    account_holder_name = models.CharField(max_length=50)
    account_IFSC_code = models.CharField(max_length=50)
    account_number = models.CharField(max_length=50)
    supplier_ref_id = models.ForeignKey(pos_inv_supplier, blank=True, null=True)
    ACCOUNT_STATUS = (
        ('0', 'inactive'),
        ('1', 'active'),
    )
    account_status = models.CharField(max_length=100, choices=ACCOUNT_STATUS)
    def __unicode__(self):
        return str(self.supplier_account_id)
    class Meta:
        db_table = "pos_inv_supplier_account_table"
        
class pos_inv_bill_payment(models.Model):
    bill_payment_id = models.AutoField(primary_key=True)
    payment_bill_number = models.ForeignKey(pos_inv_purchase_details)
    payment_date = models.DateTimeField(auto_now_add=True)
    PAYMENT_TYPE = (
        ('1', 'cash'),
        ('2', 'cheque'),
        ('3', 'online'),
    )
    payment_type = models.CharField(max_length=10, choices=PAYMENT_TYPE)
    payment_reciever = models.CharField(max_length=50, blank=True, null=True)
    payment_amount = models.CharField(max_length=50)
    payment_note = models.TextField(blank=True, null=True)
    cheque_details = models.TextField(blank=True, null=True)
    payment_bill_account = models.ForeignKey(pos_inv_supplier_account_details, blank=True, null=True)
    def __unicode__(self):
        return str(self.bill_payment_id)
    class Meta:
        db_table = "pos_inv_bill_payment_table"

class pos_inv_kitchen_department(models.Model):
    department_id = models.AutoField(primary_key=True)
    department_name = models.CharField(max_length=50)
    DEPARTMENT_STATUS = (
        ('0', 'inactive'),
        ('1', 'active'),
    )
    department_status = models.CharField(max_length=10, choices=DEPARTMENT_STATUS)
    def __unicode__(self):
        return str(self.department_id)
    class Meta:
        db_table = "pos_inv_kitchen_department"
		        
class pos_inv_kitchen_delivery(models.Model):
	kitchen_order_id = models.AutoField(primary_key=True)
	kitchen_order_number = models.CharField(max_length=100)
	kitchen_order_date = models.DateTimeField(auto_now_add=True)
	kitchen_order_arr = models.TextField()
	kitchen_ordered_by = models.ForeignKey(pos_employee, blank=True, null=True)
	ORDER_ACTION = (
		('0', 'update'),
		('1', 'send'),
		('2', 'storekeeperSend'),
		('3', 'completed'),
	)
	kitchen_order_action = models.CharField(max_length=100, choices=ORDER_ACTION)
	kitchen_department = models.ForeignKey(pos_inv_kitchen_department, blank=True, null=True)
	KITCHEN_ORDER_APPLY = (
		('0', 'chef'),
		('1', 'shopkeeper'),
	)
	kitchen_order_apply = models.CharField(max_length=100, choices=KITCHEN_ORDER_APPLY)
	kitchen_order_ref_id = models.IntegerField(blank=True, null=True)
	def __unicode__(self):
		return str(self.kitchen_order_id)
	class Meta:
		db_table = "pos_inv_kitchen_order_table"
		
class pos_inv_settings(models.Model):
    settings_logo = models.ImageField(upload_to='images/', blank=True, null=True, default='images/food-default.png')
    settings_name = models.CharField(max_length=100)
    settings_address = models.TextField()
    settings_pincode = models.CharField(max_length=20)
    landline_num = models.CharField(max_length=50)
    to_report_mail = models.TextField()
    pending_order_visibility = models.CharField(max_length=50)
    def __unicode__(self):
        return self.settings_name
    class Meta:
        db_table = 'pos_hotel_details'