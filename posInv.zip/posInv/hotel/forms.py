from django import forms
from models import pos_employee, pos_inv_category, pos_inv_product, pos_inv_supplier, pos_inv_purchase_details, pos_inv_units, pos_inv_kitchen_department, pos_inv_supplier_account_details, pos_inv_settings

        # /---- Login form ----/

class loginForm(forms.ModelForm):
    class Meta:
        model = pos_employee
        fields = ['emp_name', 'emp_password', 'emp_role']

class pos_employee_form(forms.ModelForm):
    class Meta:
        model = pos_employee
        fields = '__all__'

class pos_edit_employee_form(forms.ModelForm):
    class Meta:
        model = pos_employee
        fields = '__all__'

class inv_category_form(forms.ModelForm):
    class Meta:
        model = pos_inv_category
        fields = "__all__"

class inv_product_form(forms.ModelForm):
    class Meta:
        model = pos_inv_product
        fields = "__all__"

class inv_supplier_form(forms.ModelForm):
    class Meta:
        model = pos_inv_supplier
        fields = "__all__"

class pos_inv_units_form(forms.ModelForm):
    class Meta:
        model = pos_inv_units
        fields = "__all__"

class pos_inv_kitchen_department_form(forms.ModelForm):
    class Meta:
        model = pos_inv_kitchen_department
        fields = "__all__"

class inv_purchase_details_form(forms.ModelForm):
    class Meta:
        model = pos_inv_purchase_details
        fields = ['purchase_order_no', 'purchase_bill_number', 'purchase_order_supplier', 'purchase_SGST', 'purchase_CGST', 'purchase_discount', 'purchase_amount', 'purchase_bill_date']

class inv_supplier_acc_form(forms.ModelForm):
    class Meta:
        model = pos_inv_supplier_account_details
        fields = "__all__"

class pos_inv_settings_form(forms.ModelForm):
    class Meta:
        model = pos_inv_settings
        fields = "__all__"