# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.

class LoginForm(models.Model):
    user_name = models.CharField(max_length=200)
    user_pass = models.CharField(max_length=200)
    class Meta:
    	db_table = "login"

class hosting(models.Model):
	hosting = models.CharField(max_length=50)
	Valid_date = models.CharField(max_length=50)
	Expirey_date = models.CharField(max_length=50)
	class Meta:
		db_table = "hosting_List"

class domain(models.Model):
	Domain = models.CharField(max_length=50)
	Valid_date = models.CharField(max_length=50)
	Expirey_date = models.CharField(max_length=50)
	class Meta:
		db_table = "domain_List"