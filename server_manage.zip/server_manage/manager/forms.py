from django import forms
from .models import LoginForm, hosting, domain

class LoginModelForm(forms.ModelForm):
	class Meta:
		model = LoginForm
		fields = "__all__"

class hostingForm(forms.ModelForm):
	class Meta:
		model = hosting
		fields = "__all__"

class domainForm(forms.ModelForm):
	class Meta:
		model = domain
		fields = "__all__"