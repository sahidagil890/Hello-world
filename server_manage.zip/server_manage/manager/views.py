# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.template import loader
from django.shortcuts import render, redirect

from .forms import LoginModelForm, hostingForm, domainForm
from .models import LoginForm, hosting, domain

# Create your views here.
from django.http import HttpResponse, HttpRequest
# from pages import home


def index(request):
	if 'user' in request.session:
		del request.session['user']
	form = LoginModelForm()
	return render(request,'index.html',{'form':form})

def check_login(request):
	if request.method == "POST":
		# s = requests.Session()
		form = LoginModelForm(request.POST)
	   	if form.is_valid():
			user_name = form.cleaned_data['user_name']
			user_pass = form.cleaned_data['user_pass']
			try:
				users = LoginForm.objects.get(user_name__exact=user_name, user_pass__exact=user_pass)
				request.session['user'] = user_name
				return redirect('/dashboard')
			except:
				return redirect('/')
	else:
		return redirect('/')

def dashboard(request):
	if 'user' in request.session:
		return render(request, 'dashboard.html')
	else:
		return redirect('/')

def signout(request):
	if 'user' in request.session:
		del request.session['user']
		return redirect('/')

def hosting_list(request):
	hostings = hosting.objects.all()
	return render(request, 'hosting_list.html', {'hostings': hostings})

def hostingentry(request):
	if request.method == "POST":
		hform = hostingForm(request.POST)
		if hform.is_valid():
			try:
				hform.save()
				return redirect('/hosting_list')
			except:
				pass
	else:		
		hform = hostingForm()
	return render(request, 'insert_hosting.html', {'hform':hform})

def edit_hosting(request, id):
	Hosting = hosting.objects.get(id=id)
	return render(request, 'edit_hosting.html', {'Hosting': Hosting})

def update_host(request, id):
    Hosting = hosting.objects.get(id=id)
    hform = hostingForm(request.POST, instance = Hosting)
    if hform.is_valid():
        hform.save()
        return redirect('/hosting_list')
    return render(request, 'edit.html', {'Hosting': Hosting})

def delete_host(request, id):
	Hosting = hosting.objects.get(id=id)
	Hosting.delete()
	return redirect('/hosting_list')



def domain_list(request):
	domains = domain.objects.all()
	return render(request, 'domain_list.html', {'domains': domains})

def domainentry(request):
	if request.method == "POST":
		dform = domainForm(request.POST)
		if dform.is_valid():
			try:
				dform.save()
				return redirect('/domain_list')
			except:
				pass
	else:		
		dform = domainForm()
	return render(request, 'insert_domain.html', {'dform':dform})

def edit_domain(request, id):
	domains = domain.objects.get(id=id)
	return render(request, 'edit_domain.html', {'domains': domains})

def update_domain(request, id):
    domains = domain.objects.get(id=id)
    hform = domainForm(request.POST, instance = domains)
    if hform.is_valid():
        hform.save()
        return redirect('/domain_list')
    return render(request, 'edit_domain.html', {'domains': domains})

def delete_domain(request, id):
	domains = domain.objects.get(id=id)
	domains.delete()
	return redirect('/domain_list')