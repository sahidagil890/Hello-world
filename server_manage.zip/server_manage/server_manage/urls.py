"""server_manage URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls import url, include
from manager import views

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', views.index),
    url(r'^index/$', views.index),
    url(r'^check_login/$', views.check_login),
    url(r'^signout/$', views.signout),
    url(r'^dashboard/$', views.dashboard),

    url(r'^hosting_list/', views.hosting_list),
    url(r'^add_host/', views.hostingentry),
    url(r'^edit_host/(?P<id>[0-9]+)/$', views.edit_hosting),
    url(r'^update_host/(?P<id>[0-9]+)/$', views.update_host),
    url(r'^delete_host/(?P<id>[0-9]+)/$', views.delete_host),

    url(r'^domain_list/', views.domain_list),
    url(r'^add_domain/', views.domainentry),
    url(r'^edit_domain/(?P<id>[0-9]+)/$', views.edit_domain),
    url(r'^update_domain/(?P<id>[0-9]+)/$', views.update_domain),
    url(r'^delete_domain/(?P<id>[0-9]+)/$', views.delete_domain),
]
